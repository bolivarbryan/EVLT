//
//  TimeConverterTests.m
//  Commercial
//
//  Created by Benjamin Petit on 19/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "TimeConverter.h"

@interface TimeConverterTests : XCTestCase

@end

@implementation TimeConverterTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testOneDay {
    NSString *string = [TimeConverter stringForNumberOfDays:1.0];
    XCTAssertEqualObjects(string, @"1 jour", @"unexpected result for 1 day");
}

- (void)testTwoDays {
    NSString *string = [TimeConverter stringForNumberOfDays:2.0];
    XCTAssertEqualObjects(string, @"2 jours", @"unexpected result for 2 days");
}

- (void)testOneDayAndAHalf {
    NSString *string = [TimeConverter stringForNumberOfDays:1.5];
    XCTAssertEqualObjects(string, @"1 jour, 4 heures", @"unexpected result for 1.5 day");
}

- (void)testAWeek {
    NSString *string = [TimeConverter stringForNumberOfDays:5.0];
    XCTAssertEqualObjects(string, @"1 semaine", @"unexpected result for one week (5 days)");
}

- (void)testTwoWeeks {
    NSString *string = [TimeConverter stringForNumberOfDays:10.0];
    XCTAssertEqualObjects(string, @"2 semaines", @"unexpected result for two weeks (10 days)");
}

- (void)testOneWeekAnd2Days {
    NSString *string = [TimeConverter stringForNumberOfDays:7.0];
    XCTAssertEqualObjects(string, @"1 semaine, 2 jours", @"unexpected result for one week and 2 days (7 days)");
}

- (void)test4Hours {
    NSString *string = [TimeConverter stringForNumberOfDays:0.5];
    XCTAssertEqualObjects(string, @"4 heures", @"unexpected result for 4 hours (0.5 days)");
}

- (void)test2Weeks3Days2Hours {
    NSString *string = [TimeConverter stringForNumberOfDays:13.25];
    XCTAssertEqualObjects(string, @"2 semaines, 3 jours, 2 heures", @"unexpected result for 2 weeks 3 days and 2 hours (0.5 days)");
}

@end
