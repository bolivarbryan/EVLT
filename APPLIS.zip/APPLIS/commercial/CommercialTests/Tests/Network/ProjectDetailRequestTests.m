//
//  ProjectDetailRequestTests.m
//  Commercial
//
//  Created by Benjamin Petit on 29/10/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "ProjectDetailRequest.h"
#import "Projet.h"

@interface ProjectDetailRequestTests : XCTestCase

@property (strong, nonatomic) ProjectDetailRequest *request;

@end

@implementation ProjectDetailRequestTests

- (void)setUp {
    [super setUp];
    ProjectDetailRequest *r = [[ProjectDetailRequest alloc] init];
    r.projectID = @"147";
    self.request = r;
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExpectedProjectIdIsRequested {
    XCTAssertEqualObjects([self.request postArguments], @"chantier_id=147", @"not passing correct POST arguments");
}

- (void)testEndpoint {
    XCTAssertEqualObjects([self.request serviceEndpoint], @"import_detail_projet.php", @"not requesting correct endpoint");
}

#pragma mark - Parsing

- (void)testParsingNil {
    id result = [self.request parseObject:nil];
    XCTAssertNil(result, @"Should have a nil object after parsing a nil JSON object");
}

- (void)testParsingCorrectObject {
    NSDictionary *json = @{
        @"chantier_id": @"147",
        @"type": @"Entretien Chaudiere ",
        @"statut": @"Visite faite",
        @"prix_ht": @"1000.00",
        @"tva": @"20%",
        @"prix_ttc": @"1200.00",
        @"commentaire": @"Note about project",
        @"numero": @"45",
        @"rue": @"Rue cauchoise",
        @"code_postal": @"76000",
        @"ville": @"Rouen",
        @"date": @"2014-10-30",
        @"duree_chantier": @"1",
        @"nature_date": @"Date proposee",
        @"gaetan": @"non",
        @"fred": @"oui",
        @"denis": @"oui",
        @"vincent": @"non"
        };
    
    id result = [self.request parseObject:json];
    XCTAssertNotNil(result);
    XCTAssertTrue([result isKindOfClass:[Projet class]]);
    Projet *p = (Projet *)result;
    XCTAssertEqualObjects(p.note, @"Note about project");
}

@end
