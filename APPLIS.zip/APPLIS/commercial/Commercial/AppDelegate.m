//
//  AppDelegate.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 30/01/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "AppDelegate.h"
#import "UIColor+Palette.h"
#import "DropBoxManager.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    //DROPBOX
    DBSession *dbSession = [[DBSession alloc]
                            initWithAppKey:@"5fzj65nhs3znvf6"
                            appSecret:@"3mekuljd36n2750"
                            root:kDBRootAppFolder]; // either kDBRootAppFolder or kDBRootDropbox
    [DBSession setSharedSession:dbSession];
    
    // WHITE STATUS BAR
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
    // GREEN BARS WITH WHITE CONTENT
    UINavigationController *navController = (UINavigationController *)self.window.rootViewController;
    
    // COULEUR BARRE
    if ([navController.navigationBar respondsToSelector:@selector(setBarTintColor:)]) {
        [UINavigationBar appearance].barTintColor = [UIColor accentColor];
        navController.toolbar.barTintColor = [UIColor accentColor];
        [UINavigationBar appearance].tintColor = [UIColor navBarTextColor];
        navController.toolbar.TintColor = [UIColor navBarTextColor];
    }
    else {
        [UINavigationBar appearance].tintColor = [UIColor accentColor];
        navController.toolbar.TintColor = [UIColor accentColor];
    }
    
    navController.navigationBar.translucent = NO;
    navController.toolbar.translucent = NO;
    
    NSDictionary *textTitleOptions = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil];
    [navController.navigationBar setTitleTextAttributes:textTitleOptions];
    
    // Override point for customization after application launch.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        UISplitViewController *splitViewController = (UISplitViewController *)self.window.rootViewController;
        UINavigationController *navigationController = [splitViewController.viewControllers lastObject];
        splitViewController.delegate = (id)navigationController.topViewController;
    }
    return YES;
     
}



- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    
    if ([[DBSession sharedSession] handleOpenURL:url]) {
        
        if ([[DBSession sharedSession] isLinked]) {
            
            NSLog(@"CONNEXION FAITE");
            
        }
        
        return YES;
        
    }
    
    // Add whatever other url handling code your app requires here
    
    return NO;
    
}



							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
