//
//  zonesProjetViewController.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 24/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Projet.h"
#import "Zone.h"

@interface zonesProjetViewController : UITableViewController{
    
    NSMutableArray *listeAffiche;
}


@property (strong, nonatomic) Projet *projet;

@property (strong, nonatomic) NSArray *zones;

@property (strong, nonatomic) NSString *statutZone;

- (IBAction)addZone:(id)sender;

@end
