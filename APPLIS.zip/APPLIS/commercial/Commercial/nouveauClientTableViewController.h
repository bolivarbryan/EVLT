//
//  nouveauClientTableViewController.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 05/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Client.h"

@interface nouveauClientTableViewController : UITableViewController<UITextFieldDelegate>

@property (strong, nonatomic) Client *client;

@property (strong, nonatomic) CLGeocoder *geocoder;

@property (strong, nonatomic) IBOutlet UITextField *nomCell;
@property (strong, nonatomic) IBOutlet UITextField *prenomCell;
@property (strong, nonatomic) IBOutlet UITextField *numeroCell;
@property (strong, nonatomic) IBOutlet UITextField *rueCell;
@property (strong, nonatomic) IBOutlet UITextField *codePostalCell;
@property (strong, nonatomic) IBOutlet UITextField *villeCell;
@property (strong, nonatomic) IBOutlet UITextField *portableCell;
@property (strong, nonatomic) IBOutlet UITextField *fixeCell;
@property (strong, nonatomic) IBOutlet UITextField *mailCell;

@property (strong, nonatomic) NSString *statut;

@property (strong, nonatomic) NSString *latitude;
@property (strong, nonatomic) NSString *longitude;

- (IBAction)boutonValider:(id)sender;

@end
