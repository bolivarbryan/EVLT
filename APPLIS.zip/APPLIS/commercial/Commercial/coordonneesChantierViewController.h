//
//  coordonneesChantierViewController.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 04/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "Projet.h"

@interface coordonneesChantierViewController : UIViewController <CLLocationManagerDelegate, UITextFieldDelegate>{
    CLLocationManager* locationManager;
    NSMutableArray *commentaire;
}

@property (strong, nonatomic) CLGeocoder *geocoder;

@property (strong, nonatomic) Projet *projet;

@property (strong, nonatomic) NSString *latitude;
@property (strong, nonatomic) NSString *longitude;

@property (strong, nonatomic) IBOutlet UITextView *commentaireText;

@property (strong, nonatomic) IBOutlet UITextField *numeroText;

@property (strong, nonatomic) IBOutlet UITextField *rueText;

@property (strong, nonatomic) IBOutlet UITextField *codePostalText;

@property (strong, nonatomic) IBOutlet UITextField *villeText;

- (IBAction)geolocalise:(id)sender;

@property (strong, nonatomic) IBOutlet UISwitch *geolocalisationSwitch;

@property (strong, nonatomic) IBOutlet UILabel *geolocalisationOK;

@property (strong, nonatomic) IBOutlet UILabel *geolocalisationText;

- (IBAction)boutonValider:(id)sender;

@end
