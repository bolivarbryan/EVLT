//
//  photosDetailViewController.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 17/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DropboxManager.h"
#import "Projet.h"
#import "Photo.h"

@interface photosDetailViewController : UIViewController <DropBoxDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate,  UITextFieldDelegate, UIActionSheetDelegate>{
    
    DropboxManager *objManager;
    
    UIImagePickerController *picker;
    int compteur;
    
    IBOutlet UIBarButtonItem *boutonAjout;
    IBOutlet UIImageView *photo;
    
    NSMutableArray *listeProjets;
    
    IBOutlet UITextField *commentaire;
}

@property (strong, nonatomic) Photo *photoActive;

@property (strong, nonatomic) Projet *projet;

@property (nonatomic,assign) DropboxManager *objManager;

@property (nonatomic, strong) DBRestClient *restClient;

@property (strong, nonatomic) NSString *photoURL;

@property (strong, nonatomic) NSString *statutRequete;

@property (strong, nonatomic) id statut;
@property (strong, nonatomic) id ligne;
@property (strong, nonatomic) id photoID;
@property (strong, nonatomic) id chantierSelectionne;

@property (strong, nonatomic) IBOutlet UITextField *commentairePhoto;

@property (strong, nonatomic) IBOutlet UISegmentedControl *choix;
@property (strong, nonatomic) NSString *photoStr;

@property (retain, nonatomic) IBOutlet UILabel *texteAjout;

@property (retain, nonatomic) IBOutlet UIImageView *logoVide;

- (IBAction)boutonPhoto:(id)sender;
- (IBAction)boutonCommentaire:(id)sender;



@end

