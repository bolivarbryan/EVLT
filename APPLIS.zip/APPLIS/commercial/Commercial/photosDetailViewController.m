//
//  photosDetailViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 17/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "photosDetailViewController.h"
#import "detailProjetViewController.h"
#import "PhotosRequest.h"
#import "Communicator.h"

@interface photosDetailViewController ()

@end

@implementation photosDetailViewController
@synthesize objManager;
@synthesize commentairePhoto;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{

    [super viewDidLoad];
    
    commentaire.delegate = self;
    self.commentairePhoto.delegate = self;
    self.statutRequete = @"CREATION";
    
    self.texteAjout.hidden = NO;
    self.logoVide.image = [UIImage imageNamed: @"valider.png"];
    
    if ([self.statut  isEqual: @"CREATION"]) {

        self.photoActive = [Photo new];
      //  self.photoActive.commentaire = @"";

    }
    
    if ([self.statut  isEqual: @"EXISTE"]) {
        
        self.texteAjout.hidden = YES;
        self.statutRequete = @"EXISTE";
        
        self.commentairePhoto.text = self.photoActive.commentaire;
        photo.image = self.photoActive.image;
        self.choix.hidden = YES;
    
    }
    
    if ([self.photoActive.commentaire  isEqual: @""]) {
        NSLog(@"PAS DE COMMENTAIRE");
        self.logoVide.image = [UIImage imageNamed: @"vide.png"];
    }
    if (self.photoActive.commentaire  == nil) {
        NSLog(@"COMMENTAIRE NUL");
        self.logoVide.image = [UIImage imageNamed: @"vide.png"];
    }

    
    objManager = [DropboxManager dropBoxManager];
    objManager.apiCallDelegate =self;
    [objManager initDropbox];
    
    self.restClient = [[DBRestClient alloc] initWithSession:[DBSession sharedSession]];
    self.restClient.delegate = self;
    
    commentairePhoto.delegate = self;
    [commentairePhoto resignFirstResponder];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    
    
}

-(void)dismissKeyboard {
    [commentairePhoto resignFirstResponder];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [commentairePhoto resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:0];
  //  [self envoiDonnees];
}

- (void)imagePickerController:(UIImagePickerController *) Picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    photo.image = [info objectForKey:UIImagePickerControllerOriginalImage];
    [picker dismissModalViewControllerAnimated:YES];
    
    
     boutonAjout.enabled = YES;
    
}

- (IBAction)boutonPhoto:(id)sender {
    
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Ajout ou modification de photo" delegate:self cancelButtonTitle:@"Annuler" destructiveButtonTitle:nil otherButtonTitles:@"Ajouter une photo",@"Prendre une photo", nil];
    action.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [action showInView:self.view];
    [self parentViewController];
    
}

- (IBAction)boutonCommentaire:(id)sender {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Commentaire" message:@"Entrer un commentaire pour la photo" delegate:self cancelButtonTitle:@"Annuler" otherButtonTitles:@"Valider", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert textFieldAtIndex:0].text = self.photoActive.commentaire;
    [alert show];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
        self.photoActive.commentaire = [alertView textFieldAtIndex:0].text;
        self.logoVide.image = [UIImage imageNamed: @"valider.png"];
}

// SELECTION ORIGINE PHOTO
 -(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
 {
 picker = [[UIImagePickerController alloc] init];
 
 switch (buttonIndex) {
 case 0:
 picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
 picker.delegate= self;
 picker.allowsEditing = YES;
 [self presentModalViewController:picker animated:YES];
 
 break;
 
 case 1:
 picker.sourceType = UIImagePickerControllerSourceTypeCamera;
 picker.delegate= self;
 picker.allowsEditing = YES;
 [self presentModalViewController:picker animated:YES];
 
 default:
 break;
 }
 
 }

- (IBAction)ajouterPhoto:(id)sender {
    
    [self testDropBox];
    
    [self performSelector:@selector(envoiDonnees) withObject:nil afterDelay:5];
    [self performSegueWithIdentifier:@"retourProjet" sender:self];
    
}

- (void)testDropBox
{

  //  NSLog(@"DEBUT TEST DROPBOX");
    
    NSString *tmpJpegFile = [NSTemporaryDirectory() stringByAppendingPathComponent:@"Temp.jpg"];
    [UIImageJPEGRepresentation(photo.image, 0.2) writeToFile:tmpJpegFile atomically:NO];
    NSString *destDir = @"/";
    NSString *filename = [NSString stringWithFormat:@"#%@.jpg", self.projet.identifier];
    [[self restClient] uploadFile:filename toPath:destDir
                    withParentRev:nil fromPath:tmpJpegFile];
}

- (void)restClient:(DBRestClient *)client uploadedFile:(NSString *)destPath
              from:(NSString *)srcPath metadata:(DBMetadata *)metadata {
    NSLog(@"File uploaded successfully to path: %@", metadata.path);
    self.photoActive.url = metadata.path;
    NSLog(@"REST ENVOYE A : %@", metadata.path);
  //  [self envoiDonnees];
}

- (void)restClient:(DBRestClient *)client uploadFileFailedWithError:(NSError *)error {
    NSLog(@"File upload failed with error: %@", error);
}

/*

// FONCTION POUR INDIQUER VITESSE CHARGEMENT
 
-(void) restClient:(DBRestClient *)client uploadProgress:(CGFloat)progress forFile:(NSString *)destPath from:(NSString *)srcPath {
    static NSDate* date = nil;
    static double oldUploadedFileSize = 0;
    if (!date) {
        date = [[NSDate date] retain];
    } else {
        NSTimeInterval sec = -[date timeIntervalSinceNow];
        [date release];
        date = [[NSDate date] retain];
        NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:srcPath error:nil];
        double uploadedFileSize = (double)[fileAttributes fileSize] * progress;
        if (sec) {
            NSLog(@"speed approx. %.2f KB/s", (uploadedFileSize - oldUploadedFileSize )/1024.0 / sec );
        }
        oldUploadedFileSize = uploadedFileSize;
    }
    
}
*/

#pragma mark -
#pragma mark File upload delegate

- (void)finishedUploadFile
{
    NSLog(@"Uploaded successfully.");
}

- (void)failedToUploadFile:(NSString*)withMessage
{
    NSLog(@"Failed to upload error is %@",withMessage);
}

- (void)envoiDonnees
{
    PhotosRequest *request = [[PhotosRequest alloc] init];
    request.projectID = self.projet.identifier;
    request.statut = self.statutRequete;
    request.commentaire = self.photoActive.commentaire;
    request.url = self.photoActive.url;
    Communicator *comm = [[Communicator alloc] init];
    [comm performRequest:request];

}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)img editingInfo:(NSDictionary *)editInfo
{
    photo.image = img;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    if ([[segue identifier] isEqualToString:@"retourProjet"]) {
        detailProjetViewController *dvc = [segue destinationViewController];
        dvc.chantierSelectionne = self.projet.identifier;
    }

}

- (void)dealloc {
    [_texteAjout release];
    [_logoVide release];
    [super dealloc];
}
@end
