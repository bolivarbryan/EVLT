//
//  MasterViewController.h
//  TESTS
//
//  Created by Emmanuel Levasseur on 30/01/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Client.h"
#define FindURL @"http://www.envertlaterre.fr/PHP/remplissage_accueil.php"

@interface MasterViewController : UITableViewController {
    
    NSMutableArray *listeAffiche;
    NSMutableArray *tampon;
    NSMutableArray *tampon2;
    // TEST
    NSMutableArray *maListe;
}

@property (strong, nonatomic) Client *clientAEditer;

@property (retain, nonatomic) IBOutlet UISearchBar *recherche;

@property (strong, nonatomic) NSArray *clients;

@property (assign, nonatomic) int index;

@property (strong, nonatomic) IBOutlet UISegmentedControl *choix;

- (IBAction)choixActifInactif:(id)sender;

@end