//
//  dateInstallationViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 03/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "dateInstallationViewController.h"
#import "DateRequest.h"
#import "Communicator.h"
#import "TimeConverter.h"
#import "Projet.h"

@interface dateInstallationViewController ()

{
    NSArray *_pickerData;
}

@end

@implementation dateInstallationViewController

@synthesize dureeLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    dureeLabel.delegate = self;
    [dureeLabel resignFirstResponder];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    // Initialize Data
    _pickerData = @[@"Heure(s)", @"Jour(s)", @"Semaine(s)"];
    [_pickerData retain];
    
    // Connect data
    self.uniteTemps.dataSource = self;
    self.uniteTemps.delegate = self;

   // _dateInstallation = self.projet.startDate;
    self.dateInstallation.date = self.projet.startDate;
    
    self.dureeLabel.text = self.projet.numberOfTime;
    
    int ligne;
    
    if ([self.projet.unitOfTime  isEqual: @"Heure(s)"]) {
        ligne = 0;
    }
    if ([self.projet.unitOfTime  isEqual: @"Jour(s)"]) {
        ligne = 1;
    }
    if ([self.projet.unitOfTime  isEqual: @"Semaine(s)"]) {
        ligne = 2;
    }
    
    NSLog(@"LIGNE %i", ligne);
    
    [self.uniteTemps selectRow:ligne inComponent:0 animated:YES];
    
}

-(void)dismissKeyboard {
    [dureeLabel resignFirstResponder];
}

// The number of columns of data
- (long)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// The number of rows of data
- (long)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _pickerData.count;
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return _pickerData[row];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    /*
    
    float duree = [self.dureeLabel.text floatValue];
    self.litteralDureeLabel.text = [TimeConverter stringForNumberOfDays:duree];
     
    */
     
    NSString *duree2 = [NSString stringWithFormat:@"%@", self.dureeLabel.text];
    self.projet.numberOfTime = duree2;
    [self.projet.numberOfTime retain];
}

- (void) tri
{
    NSInteger ligneActive = [self.uniteTemps selectedRowInComponent:0];
    
    if (ligneActive == 0) {
        self.projet.unitOfTime = @"Heure(s)";
    }
    if (ligneActive == 1) {
        self.projet.unitOfTime = @"Jour(s)";
    }
    if (ligneActive == 2) {
        self.projet.unitOfTime = @"Semaine(s)";
    }
}

- (IBAction)boutonValider:(id)sender {
    
    [self tri];
    
    NSLog(@"%@ %@",self.projet.numberOfTime, self.projet.unitOfTime);
    
    
    //   NSLocale *frLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"fr_FR"];
    NSDate *pickerDate = [_dateInstallation date];
    NSDateFormatter *formatageDate = [[NSDateFormatter alloc] init];
    [formatageDate setDateFormat:@"yyyy-MM-dd"];
    NSString *dateFormatee = [formatageDate stringFromDate:pickerDate];
    
    DateRequest *request = [[DateRequest alloc] init];
    request.projectID = self.projet.identifier;
    request.statut = @"FERME";
    request.date = dateFormatee;
    request.duree = self.projet.numberOfTime;
    request.unite = self.projet.unitOfTime;
    Communicator *comm = [[Communicator alloc] init];
    [comm performRequest:request];
    
    [self.navigationController popViewControllerAnimated:YES];
  
}

@end
