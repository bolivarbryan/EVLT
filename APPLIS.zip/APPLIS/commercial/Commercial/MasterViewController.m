//
//  MasterViewController.m
//  TESTS
//
//  Created by Emmanuel Levasseur on 30/01/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "MasterViewController.h"
#import "projetViewController.h"
#import "Projet.h"
#import "Communicator.h"
#import "ClientsListRequest.h"
#import "Client.h"
#import "DeleteRequest.h"
#import "ClientProjectsRequest.h"
#import "CoordonneesClientRequest.h"
#import "nouveauClientTableViewController.h"
#import "AppDelegate.h"

@interface MasterViewController () {
    NSMutableArray *_objects;
}

@property (strong, nonatomic) NSArray *allProjects;
@property (strong, nonatomic) NSArray *allCoordonnees;

@end

@implementation MasterViewController
{
    NSArray *searchResults;
}

- (void)awakeFromNib
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        self.clearsSelectionOnViewWillAppear = NO;
        self.preferredContentSize = CGSizeMake(320.0, 600.0);
    }
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
 /*   
    UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = CGPointMake(160, 240);
    spinner.tag = 12;
    [self.view addSubview:spinner];
    [spinner startAnimating];
    [spinner release];
  */
    
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    [self importerDonnees];
    self.navigationController.toolbar.hidden = NO;
   
    [self triStatut];
    
}

- (void)importerDonnees
{
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    
    float tailleSpinner = 80;
    float x = self.view.frame.size.width/2 - (tailleSpinner/2);
    float y = self.view.frame.size.height/2 - (tailleSpinner/2);
    
    UIImageView *customActivityIndicator = [[UIImageView alloc] initWithFrame:CGRectMake(x, y, tailleSpinner, tailleSpinner)];
    
    customActivityIndicator.animationImages = [NSArray arrayWithObjects:[UIImage imageNamed:@"depart.png"],[UIImage imageNamed:@"30 degres.png"],[UIImage imageNamed:@"60 degres.png"],[UIImage imageNamed:@"90 degres.png"],nil];
    customActivityIndicator.animationDuration = 1.0; // in seconds
    customActivityIndicator.animationRepeatCount = 0; // sets to loop
    [customActivityIndicator startAnimating]; // starts animating
    [self.view addSubview:customActivityIndicator];
    
    Communicator *communicator = [[Communicator alloc] init];
    ClientsListRequest *request = [[ClientsListRequest alloc] init];
    self.clients = (NSArray *)[communicator performRequest:request];
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSMutableSet *selectedClients = [NSMutableSet set];
    for (Client *c in self.clients) {
        if( [c.commercialLogged isEqualToString:delegate.user])
        {
            [selectedClients addObject:c];
        }
    }
    
    self.clients = [[selectedClients allObjects] mutableCopy];
    
    ClientProjectsRequest *requestProjects = [[ClientProjectsRequest alloc] init];
    self.allProjects = (NSArray *)[communicator performRequest:requestProjects];
    
    CoordonneesClientRequest *requestClients = [[CoordonneesClientRequest alloc] init];
    self.allCoordonnees = (NSArray *)[communicator performRequest:requestClients];
    
    // NSArray *newArray=[self.clients arrayByAddingObjectsFromArray:self.allCoordonnees];
    // NSLog(@"%@",newArray);
    
    [customActivityIndicator stopAnimating];
    [customActivityIndicator removeFromSuperview];
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
}

- (void)triStatut
{
    NSMutableSet *selectedClients = [NSMutableSet set];
    
    for (Projet *p in self.allProjects) {
        if (p.status == self.index) {
            Client *client = [self clientWithId:p.clientID];
            if (client.commercialActive == 1) {
                [selectedClients addObject:client];
            }
        }
    }
    
    listeAffiche = [[selectedClients allObjects] mutableCopy];
    
    NSSortDescriptor *mySorter = [[NSSortDescriptor alloc] initWithKey:@"lastName" ascending:YES];
    [listeAffiche sortUsingDescriptors:[NSArray arrayWithObject:mySorter]];
    [tampon addObjectsFromArray:listeAffiche];
    [maListe addObjectsFromArray:listeAffiche];
    [self.tableView reloadData];
    
}

/*
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    tampon2 = [[NSMutableArray alloc] init];
    [tampon2 addObjectsFromArray:tampon];
    [listeAffiche removeAllObjects];
    
    if([searchText isEqualToString:@""])
    {
        
        NSLog(@"VIDE");
        
        [listeAffiche removeAllObjects];
        [listeAffiche addObjectsFromArray:tampon]; // Restitution des données originales
        return;
    }
    
    for(NSString *name in tampon2)
    {
        NSLog(@"NOM : %@", name);
        
        
        NSRange r = [name rangeOfString:searchText];
        if(r.location != NSNotFound)
        {
            if(r.location== 0)
                [listeAffiche addObject:name];
        }
    }
    
}
*/

// DEBUT RECHERCHE
// DEBUT RECHERCHE
// DEBUT RECHERCHE

- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"name contains[c] %@", searchText];
    searchResults = [listeAffiche filteredArrayUsingPredicate:resultPredicate];
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar
                                                     selectedScopeButtonIndex]]];
    
    return YES;
}

// FIN RECHERCHE
// FIN RECHERCHE
// FIN RECHERCHE



#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
    return [searchResults count];
    }
    else {
    return [listeAffiche count];        
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier =@"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell
    Client *client = [listeAffiche objectAtIndex:indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", client.lastName, client.firstName];
    cell.detailTextLabel.text = [Projet nameForStatus:self.index];
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // SUPPRIMER LIGNE
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        Client *client = [listeAffiche objectAtIndex:indexPath.row];
        
        self.clientAEditer = client;
        
        [listeAffiche removeObjectAtIndex:indexPath.row];
        
        [self alertShow];
   
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];

        [self.tableView reloadData];
 
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @"Supprimer / Archiver";
}

- (void) alertShow  {
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"EFFACER OU ARCHIVER CLIENT" message:@"Choisir une option" delegate:self cancelButtonTitle:@"Annuler" otherButtonTitles:@"EFFACER",@"ARCHIVER",nil];
    [alertView show];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    DeleteRequest *request = [[DeleteRequest alloc] init];
    
    if (buttonIndex == 1) {
        request.requete = [NSString stringWithFormat:@"DELETE FROM `envertlaevlt`.`client` WHERE `client`.`client_id` = %@", self.clientAEditer.identifier];
    }
    
    if (buttonIndex == 2) {
        
        request.requete = @"ARCHIVE";
        request.clientID = self.clientAEditer.identifier;
    }
    
    Communicator *comm = [[Communicator alloc] init];
    [comm performRequest:request];
    
    [self importerDonnees];
    [self triStatut];

}

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

// FILTRE
- (IBAction)choixActifInactif:(id)sender {
    self.index = self.choix.selectedSegmentIndex;
    [self triStatut];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"versProjet"]) {
        NSInteger selectedIndex = [[self.tableView indexPathForSelectedRow] row];
        projetViewController *dvc = [segue destinationViewController];
        Client *client = [listeAffiche objectAtIndex:selectedIndex];
        dvc.clientSelectionne = client.identifier;
        dvc.client = client;
        
        NSMutableSet *coordonneesClients = [NSMutableSet set];
        Client *clientbis = [self clientWithId2:client.identifier];
        [coordonneesClients addObject:clientbis];
        maListe = [[coordonneesClients allObjects] mutableCopy];
        Client *c = [maListe objectAtIndex:0];
        
        dvc.client.numero =c.numero;
        dvc.client.rue = c.rue;
        dvc.client.code_postal = c.code_postal;
        dvc.client.ville = c.ville;
        dvc.client.mobilePhone = c.mobilePhone;
        dvc.client.phone = c.phone;
        dvc.client.email = c.email;
    }
    
    if ([[segue identifier] isEqualToString:@"nouveauClient"]) {
        nouveauClientTableViewController *dvc = [segue destinationViewController];
        dvc.statut = @"CREATION";
    }
    
}

- (Client *)clientWithId:(NSString *)identifier {
    for (Client *c in self.clients) {
        if ([c.identifier isEqualToString:identifier]) {
            return c;
        }
    }
    return nil;
}

- (Client *)clientWithId2:(NSString *)identifier {
    for (Client *c in self.allCoordonnees) {
        if ([c.identifier isEqualToString:identifier]) {
            return c;
        }
    }
    return nil;
}

- (void)dealloc {
    [_recherche release];
    [super dealloc];
}
@end
