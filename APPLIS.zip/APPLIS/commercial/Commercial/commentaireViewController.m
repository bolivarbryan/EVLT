//
//  commentaireViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 03/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "commentaireViewController.h"
#import "CommentaireRequest.h"
#import "Communicator.h"

@interface commentaireViewController ()

@end

@implementation commentaireViewController

//@synthesize commentaireText;



- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.commentaireText setDelegate:self];
    
    self.navigationController.toolbar.hidden = YES;
    
    self.commentaireText.text = self.projet.note;
}

- (void) textViewDidBeginEditing:(UITextView *) textView {
    
    if ([self.commentaireText.text isEqualToString:@"Notez ici vos notes, commentaires ou remarques par rapport au chantier."]) {
        [self.commentaireText setText:@""];
    }
    
}

- (IBAction)boutonValider:(id)sender {
    CommentaireRequest *request = [[CommentaireRequest alloc] init];
    request.projectID = self.projet.identifier;
    request.statut = @"FERME";
    request.commentaire = self.commentaireText.text;
    Communicator *comm = [[Communicator alloc] init];
    [comm performRequest:request];
    self.projet.note = self.commentaireText.text;
    
    [self.navigationController popViewControllerAnimated:YES];
}

@end
