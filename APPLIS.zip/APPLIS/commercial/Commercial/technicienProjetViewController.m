//  technicienViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 05/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "technicienProjetViewController.h"
#import "TechnicianStore.h"
#import "Technician.h"

@interface technicienProjetViewController ()

@end

@implementation technicienProjetViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    [self importerDonnees];
    [super viewDidLoad];
    
    
    // Test reception id chantier
    //    NSLog(self.chantierSelectionne);
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated
{
    [self exporterDonnees];
    [super viewWillDisappear:0];
    
}

- (void)importerDonnees
{

 //   NSLog(@"PROJET %@", self.projet.identifier);
    
     NSString *chantier = self.projet.identifier;
     NSString *statut =@"OUVRE";
     NSError *error;
     NSString *post = [NSString stringWithFormat:@"chantier=%@ &statut=%@", chantier, statut];
     //NSLog(post);
     NSData *dataToSend =[NSData dataWithBytes:[post UTF8String] length:[post length]];
     //NSMutableURLRequest *request =[[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://localhost/technicien_projet.php"]];
     NSMutableURLRequest *request =[[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://www.envertlaterre.fr/PHP/technicien_projet.php"]];
     [request setHTTPMethod:@"POST"];
     [request setHTTPBody:dataToSend];
     NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:Nil error:nil];
     commentaire = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    
    if (commentaire.count > 0) {
        NSDictionary *info = [commentaire objectAtIndex:0];
        
        NSArray *techs = [[TechnicianStore standardStore] availableTechnicians];
        for (Technician *t in techs) {
            if ([[info objectForKey:t.tableName] isEqualToString:@"oui"]) {
                if ([t.tableName isEqualToString:@"denis"]) {
                    denisSwitch.on = YES;
                } else if ([t.tableName isEqualToString:@"gaetan"]) {
                    gaetanSwitch.on = YES;
                } else if ([t.tableName isEqualToString:@"fred"]) {
                    fredSwitch.on = YES;
                } else if ([t.tableName isEqualToString:@"vincent"]) {
                    vincentSwitch.on = YES;
                }
            }
        }
    }

}

 - (void)exporterDonnees {
     NSString *chantier = self.projet.identifier;
     
     NSString *gaetan = @"non";
     if (gaetanSwitch.on == YES) {
         gaetan =@"oui";
     }
     NSString *fred = @"non";
     if (fredSwitch.on == YES) {
         fred =@"oui";
     }
     NSString *denis = @"non";
     if (denisSwitch.on == YES) {
         denis =@"oui";
     }
     NSString *vincent = @"non";
     if (vincentSwitch.on == YES) {
         vincent =@"oui";
     }
     
     NSString *post = [NSString stringWithFormat:@"chantier=%@&gaetan=%@&fred=%@&denis=%@&vincent=%@", chantier, gaetan, fred, denis, vincent];
     NSData *dataToSend =[NSData dataWithBytes:[post UTF8String] length:[post length]];
     //NSMutableURLRequest *request =[[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://localhost/technicien_projet.php"]];
     NSMutableURLRequest *request =[[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://www.envertlaterre.fr/PHP/technicien_projet.php"]];
     [request setHTTPMethod:@"POST"];
     [request setHTTPBody:dataToSend];
     NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:Nil error:nil];

     NSMutableArray *chosenTechs = [NSMutableArray array];
     if (self.statutDenis) {
         [chosenTechs addObject:[[TechnicianStore standardStore] technicianWithTableName:@"denis"]];
     }
     if (self.statutGaetan) {
         [chosenTechs addObject:[[TechnicianStore standardStore] technicianWithTableName:@"gaetan"]];
     }
     if (self.statutFred) {
         [chosenTechs addObject:[[TechnicianStore standardStore] technicianWithTableName:@"fred"]];
     }
     if (self.statutVincent) {
         [chosenTechs addObject:[[TechnicianStore standardStore] technicianWithTableName:@"vincent"]];
     }
     
     self.projet.technicians = chosenTechs;
 //    NSLog(@" TECHS : %@", self.projet.technicians);
 }

 
- (IBAction)gaetanSwitch:(id)sender {
    self.statutGaetan = [sender isOn];
}

- (IBAction)fredSwitch:(id)sender{
    self.statutFred = [sender isOn];
}

- (IBAction)denisSwitch:(id)sender{
    self.statutDenis = [sender isOn];
}

- (IBAction)vincentSwitch:(id)sender{
    self.statutVincent = [sender isOn];
}



@end
