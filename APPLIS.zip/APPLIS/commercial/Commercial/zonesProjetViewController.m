//
//  zonesProjetViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 24/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "zonesProjetViewController.h"
#import "COMZoneTableViewCell.h"
#import "Zone.h"
#import "COMZoneEditionViewController.h"
#import "DeleteRequest.h"
#import "Communicator.h"

@implementation zonesProjetViewController

- (void)viewDidLoad
{
    [super viewDidLoad];    
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self importerDonnees];
}

- (void)importerDonnees
{
    
    NSMutableArray*listeCharge = [[NSMutableArray alloc] init];
    
    for(Zone *zon in self.zones)
    {
        [listeCharge addObject:zon];
    }
    listeAffiche = listeCharge;
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return listeAffiche.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    COMZoneTableViewCell *cell = (COMZoneTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"zoneCell" forIndexPath:indexPath];
    
    Zone *z = [self.zones objectAtIndex:indexPath.row];
    cell.nameLabel.text = z.name;
    cell.volumeLabel.text = [NSString stringWithFormat:@"Volume : %@", z.volume];
    cell.murLabel.text = [NSString stringWithFormat:@"Iso. murs : %@", z.isoMurs];
    cell.combleLabel.text = [NSString stringWithFormat:@"Iso. combles : %@", z.isoCombles];
    cell.rampantLabel.text = [NSString stringWithFormat:@"Iso. rampants : %@", z.isoRampants];
    cell.menuiserieLabel.text = [NSString stringWithFormat:@"Menuiserie : %@", z.menuiseries];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Zone *z = self.zones[indexPath.row];
    self.statutZone = @"EXISTE";
    [self performSegueWithIdentifier:@"editZone" sender:z];
}

-(void)tableView:(UITableView*)tableView willBeginEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
    // peut rester vide
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // SUPPRIMER LIGNE
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        Zone *zone = [listeAffiche objectAtIndex:indexPath.row];
        NSString *identifiant = zone.identifier;
        
        [listeAffiche removeObjectAtIndex:indexPath.row];
        
        DeleteRequest *request = [[DeleteRequest alloc] init];
        request.requete = [NSString stringWithFormat:@"DELETE FROM `envertlaevlt`.`zones_chantier` WHERE `zones_chantier`.`zone_id` = %@", identifiant];
        Communicator *comm = [[Communicator alloc] init];
        [comm performRequest:request];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
        [self importerDonnees];
        [self.tableView reloadData];
        
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"editZone"]) {
        COMZoneEditionViewController *dvc = [segue destinationViewController];
        
        if ([self.statutZone isEqual: @"EXISTE"]) {
            NSInteger selectedIndex = [[self.tableView indexPathForSelectedRow] row];
            Zone *zoneChoisie = [self.zones objectAtIndex:selectedIndex];
            dvc.zone = zoneChoisie;
            dvc.zone.statut = self.statutZone;
        }
        
        if ([self.statutZone isEqual: @"NOUVEAU"]) {
            
            Zone *z = [[Zone alloc] init];
            z.statut = @"NOUVEAU";
            dvc.zone = z;
        }
        dvc.projet = self.projet;
        dvc.nombreZones = self.zones.count;
    }
    
}


- (IBAction)addZone:(id)sender {
    self.statutZone = @"NOUVEAU";
    [self performSegueWithIdentifier:@"editZone" sender:nil];
}
@end
