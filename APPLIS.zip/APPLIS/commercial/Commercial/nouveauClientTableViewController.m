//
//  nouveauClientTableViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 05/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "nouveauClientTableViewController.h"
#import "projetViewController.h"
#import "NewClientRequest.h"
#import "Communicator.h"
#import "AppDelegate.h"

@interface nouveauClientTableViewController ()

@end

@implementation nouveauClientTableViewController
@synthesize nomCell;
@synthesize prenomCell;
@synthesize numeroCell;
@synthesize rueCell;
@synthesize codePostalCell;
@synthesize villeCell;
@synthesize portableCell;
@synthesize fixeCell;
@synthesize mailCell;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    nomCell.delegate = self;
    prenomCell.delegate = self;
    numeroCell.delegate = self;
    rueCell.delegate = self;
    codePostalCell.delegate = self;
    villeCell.delegate = self;
    portableCell.delegate = self;
    fixeCell.delegate = self;
    mailCell.delegate = self;
    
    [nomCell resignFirstResponder];
    [prenomCell resignFirstResponder];
    [numeroCell resignFirstResponder];
    [rueCell resignFirstResponder];
    [codePostalCell resignFirstResponder];
    [villeCell resignFirstResponder];
    [portableCell resignFirstResponder];
    [fixeCell resignFirstResponder];
    [mailCell resignFirstResponder];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    if ([self.statut  isEqual: @"EXISTE"]) {
        [self remplissage];
    }

}

-(void)remplissage {
    self.nomCell.text = self.client.lastName;
    self.prenomCell.text = self.client.firstName;
    self.numeroCell.text = self.client.numero;
    self.rueCell.text = self.client.rue;
    self.codePostalCell.text = self.client.code_postal;
    self.villeCell.text = self.client.ville;
    self.portableCell.text = self.client.mobilePhone;
    self.fixeCell.text = self.client.phone;
    self.mailCell.text = self.client.email;
}

-(void)dismissKeyboard {
    [nomCell resignFirstResponder];
    [prenomCell resignFirstResponder];
    [numeroCell resignFirstResponder];
    [rueCell resignFirstResponder];
    [codePostalCell resignFirstResponder];
    [villeCell resignFirstResponder];
    [portableCell resignFirstResponder];
    [fixeCell resignFirstResponder];
    [mailCell resignFirstResponder];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)tri
{
    if ([self.numeroCell.text  isEqual: @"Nom"]){self.numeroCell.text =@"";}
    if ([self.rueCell.text  isEqual: @"Nom"]){self.rueCell.text =@"";}
    if ([self.codePostalCell.text  isEqual: @"Nom"]){self.codePostalCell.text =@"";}
    if ([self.villeCell.text  isEqual: @"Nom"]){self.villeCell.text =@"";}
    if ([self.portableCell.text  isEqual: @"Nom"]){self.portableCell.text =@"";}
    if ([self.fixeCell.text  isEqual: @"Nom"]){self.fixeCell.text =@"";}
    if ([self.mailCell.text  isEqual: @"Nom"]){self.mailCell.text =@"";}
}

- (void) recupCoordonnees
{
     if(self.geocoder == nil)
     {
     self.geocoder = [[CLGeocoder alloc] init];
     }
    
    NSString *numero = self.numeroCell.text;
    NSString *rue = self.rueCell.text;
    NSString *codePostal = self.codePostalCell.text;
    NSString *ville = self.villeCell.text;
    
    if ([self.numeroCell.text  isEqual: @"Numéro"]){numero = @"";}
    if ([self.rueCell.text  isEqual: @"Rue"]){rue = @"";}
    if ([self.codePostalCell.text  isEqual: @"Code Postal"]){codePostal = @"";}
    if ([self.villeCell.text  isEqual: @"Ville"]){ville = @"";}
    
     NSString *address = [NSString stringWithFormat:@"%@ %@ %@ %@", numero, rue, codePostal, ville];
    
    NSLog(address);
     
     [self.geocoder geocodeAddressString:address completionHandler:^(NSArray *placemarks, NSError *error) {
     
     if(placemarks.count > 0)
     {
     CLPlacemark *placemark = [placemarks objectAtIndex:0];
         
    self.latitude = [NSString stringWithFormat:@"%f", placemark.location.coordinate.latitude];
    self.longitude = [NSString stringWithFormat:@"%f", placemark.location.coordinate.longitude];
        
        NSLog(@"LAT : %@", self.latitude);
         
     [self envoi];
         
     }
     else if (error.domain == kCLErrorDomain)
     {
     switch (error.code)
     {
     case kCLErrorDenied:
     NSLog(@"ACCES REFUSE");
             [self envoi];
     break;
     case kCLErrorNetwork:
     NSLog(@"PAS DE RESEAU");
             [self envoi];
     break;
     case kCLErrorGeocodeFoundNoResult:
     NSLog(@"PAS DE RESULTAT");
             [self envoi];
     break;
     default:
     NSLog(@"ERREUR : %@", error.localizedDescription);
             [self envoi];
     break;
     }
     }
     else
     {
     NSLog(@"ERREUR : %@", error.localizedDescription);
         [self envoi];
     }
     }];
    
    

}

- (void) envoi {
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NewClientRequest *request = [[NewClientRequest alloc] init];
    request.statut = self.statut;
    request.commercial = delegate.user;
    request.clientID = self.client.identifier;
    request.nom = self.nomCell.text;
    request.prenom = self.prenomCell.text;
    request.numero = self.numeroCell.text;
    request.rue = self.rueCell.text;
    request.code_postal = self.codePostalCell.text;
    request.ville = self.villeCell.text;
    request.latitude = self.latitude;
    request.longitude = self.longitude;
    request.portable = self.portableCell.text;
    request.fixe = self.fixeCell.text;
    request.mail= self.mailCell.text;
    Communicator *comm = [[Communicator alloc] init];
    self.client = (Client *)[comm performRequest:request];
    [self performSegueWithIdentifier:@"versListeProjets" sender:self];
}

- (IBAction)boutonValider:(id)sender {
    
    [self recupCoordonnees];
    [self tri];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"versListeProjets"]) {
        projetViewController *dvc = [segue destinationViewController];
        dvc.clientSelectionne = self.client.identifier;
        dvc.client = self.client;
        dvc.client.numero =self.numeroCell.text;
        dvc.client.rue = self.rueCell.text;
        dvc.client.code_postal = self.codePostalCell.text;
        dvc.client.ville = self.villeCell.text;
        dvc.client.mobilePhone = self.portableCell.text;
        dvc.client.phone = self.fixeCell.text;
        dvc.client.email = self.mailCell.text;
    }
}

@end
