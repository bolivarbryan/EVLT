//
//  StatutProjectRequest.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 06/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "AbstractRequest.h"

@interface StatutProjectRequest : AbstractRequest

@property (strong, nonatomic) NSString *projectID;
@property (strong, nonatomic) NSString *etat;
@property (strong, nonatomic) NSString *statut;
@property (strong, nonatomic) NSString *prix;
@property (strong, nonatomic) NSString *tva;
@property (strong, nonatomic) NSString *statutAdmin;

@end
