//
//  COMZoneTableViewCell.h
//  Commercial
//
//  Created by Benjamin Petit on 28/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface COMZoneTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UILabel *volumeLabel;
@property (strong, nonatomic) IBOutlet UILabel *murLabel;
@property (strong, nonatomic) IBOutlet UILabel *combleLabel;
@property (strong, nonatomic) IBOutlet UILabel *rampantLabel;
@property (strong, nonatomic) IBOutlet UILabel *menuiserieLabel;

@end
