//
//  StatutProjetTableViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 05/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "StatutProjetTableViewController.h"
#import "ProjectValidationViewController.h"
#import "StatutProjectRequest.h"
#import "Communicator.h"

@interface StatutProjetTableViewController () <ProjectValidationViewControllerDelegate>

@end

@implementation StatutProjetTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.statut = self.projet.statutComplet;
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return ProjectStatusCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"statutCell" forIndexPath:indexPath];
    
    cell.textLabel.text = [Projet nameForStatus:(int)indexPath.row];
    BOOL selected = cell.textLabel.text == self.statut;
    cell.accessoryType = selected ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    self.indexApres = indexPath.row;
    NSString *statutModif = [Projet nameForStatus:(int)indexPath.row];
    self.statut = statutModif;
    
    if (indexPath.row == ProjectStatusAccepted) {
        [self performSegueWithIdentifier:@"validation" sender:indexPath];
    } else {
        self.projet.status = (ProjectStatus)indexPath.row;
        self.projet.statut = [Projet technicalNameForStatus:(int)indexPath.row];
    }

    [self.tableView reloadData];
    
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"validation"]) {
        UINavigationController *navCtrl = (UINavigationController *)segue.destinationViewController;
        ProjectValidationViewController *ctrl = (ProjectValidationViewController *)navCtrl.topViewController;
        ctrl.projet = self.projet;
        ctrl.delegate = self;
    }
}

#pragma mark - ProjectValidationViewControllerDelegate

- (void)projectValidationController:(ProjectValidationViewController *)controller didValidateWithTotal:(float)total tax:(float)tax {
    self.projet.status = ProjectStatusAccepted;
    [self dismissViewControllerAnimated:YES completion:NULL];
    [self.tableView reloadData];
}

- (void)projectValidationControllerDidCancel:(ProjectValidationViewController *)controller {
    [self dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)valid:(id)sender {
    
    StatutProjectRequest *request = [[StatutProjectRequest alloc] init];
    request.projectID = self.projet.identifier;
    request.etat = self.projet.statut;
    request.prix = self.projet.prix;
    request.tva = self.projet.tva;
    request.statutAdmin = @"";
    if ([self.projet.statut isEqualToString:@"Accepte"]) {
        request.statutAdmin = @"A programmer";
    }
    Communicator *comm = [[Communicator alloc] init];
    [comm performRequest:request];
    
    [self.navigationController popViewControllerAnimated:YES];
    
  //  NSLog(self.projet.prix);
  //  NSLog(self.projet.statut);
}
@end
