//
//  nouveauProjetTableViewController.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 30/10/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface nouveauProjetTableViewController : UITableViewController

@property (strong, nonatomic) NSString *clientSelectionne;

@property (strong, nonatomic) NSString *nature;
@property (strong, nonatomic) NSString *produit;
@property (strong, nonatomic) NSString *energie;

@end
