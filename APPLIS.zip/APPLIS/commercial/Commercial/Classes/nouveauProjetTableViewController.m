//
//  nouveauProjetTableViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 30/10/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "nouveauProjetTableViewController.h"
#import "Projet.h"
#import "EditableTableViewCell.h"
#import "NewProjectRequest.h"
#import "Communicator.h"

@interface nouveauProjetTableViewController () <UITextFieldDelegate>

@property (strong, nonatomic) Projet *projet;
@property (strong, nonatomic) EditableTableViewCell *otherNatureCell;

@end

@implementation nouveauProjetTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.projet = [[Projet alloc] init];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancel:)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(validate:)];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //return 3;
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
 /*   NSString *title = nil;
    switch (section) {
        case 0:
            title = @"Nature";
            break;
        case 1:
            title = @"Produit";
            break;
        case 2:
            title = @"Energie";
            break;
        default:
            break;
    }*/
    
    NSString *title = nil;
    switch (section) {
        case 0:
            title = @"Produit";
            break;
        case 1:
            title = @"Energie";
            break;
        default:
            break;
    }
    return title;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
 /*   switch (section) {
        case 0:
            return 4;
            break;
        case 1:
            return 4;
            break;
        case 2:
            return 4;
            break;
    }*/
    
    switch (section) {
        case 0:
            return 5;
            break;
        case 1:
            return 6;
            break;
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
/*    UITableViewCell *cell = nil;
    switch (indexPath.section) {
        case 0:
            cell = [self tableView:tableView natureCellAtIndexPath:indexPath];
            break;
        case 1:
            cell = [self tableView:tableView produitCellAtIndexPath:indexPath];
            break;
        case 2:
            cell = [self tableView:tableView energieCellAtIndexPath:indexPath];
            break;
    } */
    
    UITableViewCell *cell = nil;
    switch (indexPath.section) {
        case 0:
            cell = [self tableView:tableView produitCellAtIndexPath:indexPath];
            break;
        case 1:
            cell = [self tableView:tableView energieCellAtIndexPath:indexPath];
            break;
    }
    
    return cell;
}

/*
- (UITableViewCell *)tableView:(UITableView *)tableView natureCellAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;
    
    switch (indexPath.row) {
        case 0: {
            cell = [tableView dequeueReusableCellWithIdentifier:@"ProjectCell" forIndexPath:indexPath];
            cell.textLabel.text = @"Installation";
        }
            break;
        case 1: {
            cell = [tableView dequeueReusableCellWithIdentifier:@"ProjectCell" forIndexPath:indexPath];
            cell.textLabel.text = @"Dépannage";
        }
            break;
        case 2:
        {
            cell = [tableView dequeueReusableCellWithIdentifier:@"ProjectCell" forIndexPath:indexPath];
            cell.textLabel.text = @"Entretien";
        }
            break;
        case 3: {
            EditableTableViewCell *editableCell = (EditableTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"editableCell" forIndexPath:indexPath];
            editableCell.titleLabel.text = @"Autre projet";
            editableCell.textField.text = self.projet.otherNature;
            editableCell.textField.delegate = self;
            self.otherNatureCell = editableCell;
            cell = editableCell;
        }
            break;
        default:
            break;
    }
    
    if (indexPath.row == self.projet.nature) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        self.nature = cell.textLabel.text;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    return cell;
    
}
*/

- (UITableViewCell *)tableView:(UITableView *)tableView produitCellAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ProjectCell" forIndexPath:indexPath];
    
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"Poêle";
            break;
        case 1:
            cell.textLabel.text = @"Chaudière";
            break;
        case 2:
            cell.textLabel.text = @"Pompe à chaleur";
            break;
        case 3:
            cell.textLabel.text = @"Ballon thermodynamique";
            break;
        case 4:
            cell.textLabel.text = @"Solaire";
            break;
        default:
            break;
    }
    
    if (indexPath.row == self.projet.produit) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        self.produit = cell.textLabel.text;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView energieCellAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ProjectCell" forIndexPath:indexPath];
    
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"Granulés";
            break;
        case 1:
            cell.textLabel.text = @"Bois bûches";
            break;
        case 2:
            cell.textLabel.text = @"Gaz";
            break;
        case 3:
            cell.textLabel.text = @"Fioul";
            break;
        case 4:
            cell.textLabel.text = @"Thermique";
            break;
        case 5:
            cell.textLabel.text = @"PV";
            break;
        default:
            break;
    }
    
    if (indexPath.row == self.projet.energie) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        self.energie = cell.textLabel.text;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
            
     /*
        case 0:
            self.projet.nature = (ProjetNature)indexPath.row;
            break;
        case 1:
            self.projet.produit = (ProjetProduit)indexPath.row;
            break;
        case 2:
            self.projet.energie = (ProjetEnergie)indexPath.row;
            break;
        default:
            break;
    } */
      
        case 0:
            self.projet.produit = (ProjetProduit)indexPath.row;
            break;
        case 1:
            self.projet.energie = (ProjetEnergie)indexPath.row;
            break;
        default:
            break;
    }
      
    [self.tableView reloadData];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.otherNatureCell.textField resignFirstResponder];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
//    if (self.otherNatureCell.textField == textField) {
 //       UITableViewCell *oldCell = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:self.projet.nature inSection:0]];
 //       oldCell.accessoryType = UITableViewCellAccessoryNone;
        self.projet.nature = ProjetNatureOther;
        self.nature = @"Autre projet";
        self.otherNatureCell.accessoryType = UITableViewCellAccessoryCheckmark;
  //  }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
//    if (self.otherNatureCell.textField == textField) {
        self.projet.otherNature = textField.text;
        self.nature = textField.text;
 //   }
}

#pragma mark - UI Actions

- (void)validate:(id)sender {
    
 //   NSString *test = [NSString stringWithFormat:@"%@ %@ %@", self.nature, self.produit, self.energie];
    
    NSString *test = [NSString stringWithFormat:@"Installation %@ %@", self.produit, self.energie];
    
    NewProjectRequest *request = [[NewProjectRequest alloc] init];
    request.clientID = self.clientSelectionne;
    request.type = test;
    Communicator *comm = [[Communicator alloc] init];
    [comm performRequest:request];
    
   // [self performSegueWithIdentifier:@"versDetailProjet" sender:nil];
    
    [self dismissViewControllerAnimated:YES completion:NULL];
    
    
}

- (void)cancel:(id)sender {
    [self dismissViewControllerAnimated:YES completion:NULL];
}
 
@end
