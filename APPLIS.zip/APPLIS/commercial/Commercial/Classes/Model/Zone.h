//
//  Zone.h
//  Commercial
//
//  Created by Benjamin Petit on 28/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Zone : NSObject

@property (strong, nonatomic) NSString *statut;
@property (strong, nonatomic) NSString *identifier;
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *volume;
@property (strong, nonatomic) NSString *isoMurs;
@property (strong, nonatomic) NSString *isoCombles;
@property (strong, nonatomic) NSString *isoRampants;
@property (strong, nonatomic) NSString *menuiseries;

@end
