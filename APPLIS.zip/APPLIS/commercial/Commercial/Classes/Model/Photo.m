//
//  Photo.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 17/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "Photo.h"

@implementation Photo

@end