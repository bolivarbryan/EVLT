//
//  Projet.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 28/10/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "Projet.h"

@implementation Projet

+ (NSString *)nameForStatus:(ProjectStatus)status {
    NSString *name = nil;
    switch (status) {
        case ProjectStatusVisiteDone:
            name = @"Visite technique faite";
            break;
        case ProjectStatusSent:
            name = @"Devis envoyé";
            break;
        case ProjectStatusAccepted:
            name = @"Devis accepté";
            break;
        case ProjectStatusInactif:
            name = @"Inactif";
            break;
        default:
            name = @"Statut inconnu";
    }
    return name;
}

+ (NSString *)technicalNameForStatus:(ProjectStatus)status {
    NSString *name = nil;
    switch (status) {
        case ProjectStatusVisiteDone:
            name = @"Visite faite";
            break;
        case ProjectStatusSent:
            name = @"Actif";
            break;
        case ProjectStatusAccepted:
            name = @"Accepte";
            break;
        case ProjectStatusInactif:
            name = @"Inactif";
            break;
        default:
            name = @"Statut inconnu";
    }
    return name;
}

+ (ProjectStatus)statusForName:(NSString *)name {
    for (int i = 0; i < ProjectStatusCount; i++) {
        if ([name isEqualToString:[self technicalNameForStatus:i]]) {
            return i;
        }
    }
    NSLog(@"Unknown status : %@", name);
    return ProjectStatusCount; // Inconnu
}

@end
