//
//  User.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 23/07/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "User.h"

@implementation User

@end
