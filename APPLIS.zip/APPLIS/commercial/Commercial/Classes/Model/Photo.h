//
//  Photo.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 28/04/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Photo : NSObject

@property (strong, nonatomic) NSString *identifier;
@property (strong, nonatomic) NSString *url;
@property (strong, nonatomic) NSString *commentaire;

@property (strong, nonatomic) UIImage *image;
@property (strong, nonatomic) NSData *data;

//NSData *data

@end
