//
//  StatutProjetTableViewController.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 05/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Projet.h"

@interface StatutProjetTableViewController : UITableViewController

@property (strong, nonatomic) Projet *projet;

@property (strong, nonatomic) NSString *statut;

@property (assign, nonatomic) int indexAvant;
@property (assign, nonatomic) int indexApres;

- (IBAction)valid:(id)sender;

@end
