//
//  NewProjectRequest.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 22/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "NewProjectRequest.h"
#import "Projet.h"

@implementation NewProjectRequest

- (NSString *)postArguments {
    return [NSString stringWithFormat:@"client_id=%@&type=%@", self.clientID, self.type];
}

- (NSString *)serviceEndpoint {
    return @"nouveau_projet.php";
}


- (id)parseObject:(id)object {
    Projet *projet = nil;
    
    if (object && [object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dico = (NSDictionary *)object;
        projet = [Projet new];
        projet.identifier = dico[@"chantier_id"];
        
    }
    
    return projet;
}


@end
