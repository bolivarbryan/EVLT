//
//  Connexion.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 23/07/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "Connexion.h"
#import "User.h"
#import "AppDelegate.h"

@implementation Connexion


- (NSString *)postArguments {
    return [NSString stringWithFormat:@"login=%@&password=%@", self.login, self.password];
}

- (NSString *)serviceEndpoint {
    return @"connect.php";
}

- (id)parseObject:(id)object {
    User *user = nil;
    
    if (object && [object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dico = (NSDictionary *)object;
        user = [User new];
        user.user = dico[@"profil"];
        
    }
    
    return user;
}

@end
