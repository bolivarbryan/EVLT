//
//  Connexion.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 23/07/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AbstractRequest.h"

@interface Connexion : AbstractRequest

@property (strong, nonatomic) NSString *login;
@property (strong, nonatomic) NSString *password;

@end
