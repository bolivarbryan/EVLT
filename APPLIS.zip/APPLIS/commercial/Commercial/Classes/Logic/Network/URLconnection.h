//
//  URLconnection.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 26/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface URLConnection : NSObject <NSURLConnectionDataDelegate, NSURLConnectionDelegate>

+ (NSData *)sendSynchronousRequest:(NSURLRequest *)request
                 returningResponse:(NSURLResponse **)response
                             error:(NSError **)error;

@end
