//
//  PhotosRequest.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 28/04/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "AbstractRequest.h"

@interface PhotosRequest : AbstractRequest

@property (strong, nonatomic) NSString *projectID;
@property (strong, nonatomic) NSString *statut;
@property (strong, nonatomic) NSString *commentaire;
@property (strong, nonatomic) NSString *url;

@end
