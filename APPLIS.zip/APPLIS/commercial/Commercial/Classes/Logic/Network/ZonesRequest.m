//
//  ZonesRequest.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 04/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "ZonesRequest.h"
#import "Zone.h"

@implementation ZonesRequest

- (NSString *)postArguments {
    return [NSString stringWithFormat:@"chantier_id=%@&action=%@&zone_id=%@&nom=%@&volume=%@&murs=%@&combles=%@&rampants=%@&menuiseries=%@", self.projectID, self.action, self.zoneID, self.nom, self.volume, self.murs, self.combles, self.rampants, self.menuiseries];
}

- (NSString *)serviceEndpoint {
    return @"zones_projet.php";
}

- (id)parseObject:(id)object {
    NSMutableArray *zones = [NSMutableArray array];
    
    if (object && [object isKindOfClass:[NSArray class]]) {
        NSArray *jsonArray = (NSArray *)object;
        for (NSDictionary *reseauJSON in jsonArray) {
            Zone *z = [Zone new];
            z.name = reseauJSON[@"nom_zone"];
            z.identifier = reseauJSON[@"zone_id"];
            z.volume = reseauJSON[@"volume_zone"];
            z.isoMurs = reseauJSON[@"iso_murs"];
            z.isoCombles = reseauJSON[@"iso_combles"];
            z.isoRampants = reseauJSON[@"iso_rampants"];
            z.menuiseries = reseauJSON[@"menuiseries"];
            
            [zones addObject:z];
        }
        
    }
    
    return zones;
}

@end

