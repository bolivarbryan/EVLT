//
//  ZonesRequest.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 04/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "AbstractRequest.h"

@interface ZonesRequest : AbstractRequest

@property (strong, nonatomic) NSString *projectID;
@property (strong, nonatomic) NSString *zoneID;

//@property (strong, nonatomic) NSString *type;

@property (strong, nonatomic) NSString *statut;
@property (strong, nonatomic) NSString *action;

@property (strong, nonatomic) NSString *nom;
@property (strong, nonatomic) NSString *volume;
@property (strong, nonatomic) NSString *murs;
@property (strong, nonatomic) NSString *combles;
@property (strong, nonatomic) NSString *rampants;
@property (strong, nonatomic) NSString *menuiseries;

@end
