//
//  TechnicianStore.m
//  Commercial
//
//  Created by Benjamin Petit on 29/10/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "TechnicianStore.h"
#import "Technician.h"

@interface TechnicianStore()

@property (strong, nonatomic) NSArray* technicians;

@end

@implementation TechnicianStore

+ (id)standardStore {
    static TechnicianStore *sharedStore = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedStore = [[self alloc] init];
    });
    return sharedStore;
}

- (id)init {
    if (self = [super init]) {
    }
    return self;
}

#pragma mark - API

- (NSArray *)availableTechnicians {
    return self.technicians;
}

- (Technician *)technicianWithTableName:(NSString *)tableName {
    for (Technician *t in self.technicians) {
        if ([t.tableName isEqualToString:tableName]) {
            return t;
        }
    }
    return nil;
}

#pragma mark - Accessors

- (NSArray *)technicians {
    if (!_technicians) {
        Technician *denis = [[Technician alloc] initWithName:@"Denis" tableName:@"denis"];
        Technician *gaetan = [[Technician alloc] initWithName:@"Gaëtan" tableName:@"gaetan"];
        Technician *fred = [[Technician alloc] initWithName:@"Fred" tableName:@"fred"];
        Technician *vincent = [[Technician alloc] initWithName:@"Vincent" tableName:@"vincent"];
        
        self.technicians = @[denis, gaetan, fred, vincent];
    }
    return _technicians;
}

@end
