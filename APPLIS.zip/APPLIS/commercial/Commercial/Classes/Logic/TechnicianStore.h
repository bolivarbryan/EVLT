//
//  TechnicianStore.h
//  Commercial
//
//  Created by Benjamin Petit on 29/10/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Technician;

@interface TechnicianStore : NSObject

+ (id)standardStore;

- (NSArray *)availableTechnicians;
- (Technician *)technicianWithTableName:(NSString *)tableName;

@end
