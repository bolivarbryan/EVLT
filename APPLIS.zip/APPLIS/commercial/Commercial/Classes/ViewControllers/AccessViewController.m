//
//  ACCESS.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 23/07/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "AccessViewController.h"
#import "Communicator.h"
#import "Connexion.h"
#import "User.h"
#import "AppDelegate.h"

@implementation AccessViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.login resignFirstResponder];
    [self.password resignFirstResponder];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
}

-(void)dismissKeyboard {
    [self.login resignFirstResponder];
    [self.password resignFirstResponder];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)dealloc {
    [_login release];
    [_password release];
    [super dealloc];
}

- (IBAction)connect:(id)sender {
    
    Connexion *request = [[Connexion alloc] init];
    request.login = self.login.text;
    request.password = self.password.text;
    Communicator *comm = [[Communicator alloc] init];
    self.utilisateurs = (NSArray *)[comm performRequest:request];
    
    NSMutableSet *users = [NSMutableSet set];
    [users addObject:self.utilisateurs];
    
    maListe = [[users allObjects] mutableCopy];
    User *c = [maListe objectAtIndex:0];
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    delegate.user = c.user;
    
  //  NSLog(@"USER : %@", delegate.user);
    
    if(![delegate.user isEqualToString:@""])
    {
     [self performSegueWithIdentifier:@"logged" sender:self];
    }
    
    if([delegate.user isEqualToString:@""])
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"EVLT" message:@"Pseudo ou mot de passe incorrect !" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        [self.navigationController popViewControllerAnimated:YES];
    }
   
    
    
}
@end
