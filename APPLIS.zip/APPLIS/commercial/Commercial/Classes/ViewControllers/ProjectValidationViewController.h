//
//  ProjectValidationViewController.h
//  Commercial
//
//  Created by Benjamin Petit on 04/02/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Projet.h"

@protocol ProjectValidationViewControllerDelegate;

@interface ProjectValidationViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) Projet *projet;

@property (strong, nonatomic) id<ProjectValidationViewControllerDelegate> delegate;
@property (strong, nonatomic) IBOutlet UITextField *totalTextField;
@property (strong, nonatomic) IBOutlet UITextField *taxTextField;

@end

@protocol ProjectValidationViewControllerDelegate <NSObject>

- (void)projectValidationController:(ProjectValidationViewController *)controller didValidateWithTotal:(float)total tax:(float)tax;

- (void)projectValidationControllerDidCancel:(ProjectValidationViewController *)controller;

@end
