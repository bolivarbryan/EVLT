//
//  ReseauxECSTableViewController.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 04/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Projet.h"
#import "Reseau.h"

@interface ReseauxECSTableViewController : UITableViewController{
    
    NSMutableArray *listeAffiche;
}

@property (strong, nonatomic) NSArray *reseaux;

@property (assign, nonatomic) ReseauType reseauType;
@property (strong, nonatomic) NSString *chantierSelectionne;
@property (strong, nonatomic) Projet *projet;

@property (strong, nonatomic) NSString *statutReseau;

- (IBAction)addReseau:(id)sender;

@end
