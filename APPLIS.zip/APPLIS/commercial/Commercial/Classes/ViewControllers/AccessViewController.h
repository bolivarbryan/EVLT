//
//  ACCESS.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 23/07/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"

@interface AccessViewController : UIViewController{

    NSMutableArray *maListe;
}


@property (strong, nonatomic) User *utilisateur;

@property (strong, nonatomic) NSArray *utilisateurs;

@property (retain, nonatomic) IBOutlet UITextField *login;
@property (retain, nonatomic) IBOutlet UITextField *password;

- (IBAction)connect:(id)sender;

@end
