//
//  ReseauECSEditionViewController.h
//  Commercial
//
//  Created by Emmanuel Levasseur on 04/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Reseau.h"
#import "Projet.h"

@interface ReseauECSEditionViewController : UITableViewController

@property (strong, nonatomic) Projet *projet;
@property (strong, nonatomic) Reseau *reseau;
@property (strong, nonatomic) NSString *statut;

@property (nonatomic, assign) int nombreReseaux;

@end
