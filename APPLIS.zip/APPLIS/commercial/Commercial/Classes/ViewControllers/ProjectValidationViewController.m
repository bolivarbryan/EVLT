//
//  ProjectValidationViewController.m
//  Commercial
//
//  Created by Benjamin Petit on 04/02/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "ProjectValidationViewController.h"

@interface ProjectValidationViewController ()

@end

@implementation ProjectValidationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(validate:)];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancel:)];
    self.totalTextField.text = self.projet.prix;
    self.taxTextField.text = self.projet.tva;
    self.projet.statut = @"Accepte";
}

- (void)validate:(id)sender {
    if ([self.delegate respondsToSelector:@selector(projectValidationController:didValidateWithTotal:tax:)]) {
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        self.projet.prix = self.totalTextField.text;
        self.projet.tva = self.taxTextField.text;
        //  self.projet.statutAdministratif = @"A programmer";
        float total = [[formatter numberFromString:self.totalTextField.text] floatValue];
        float tax = [[formatter numberFromString:self.taxTextField.text] floatValue];
        [self.delegate projectValidationController:self didValidateWithTotal:total tax:tax];
    }
}

- (void)cancel:(id)sender {
    if ([self.delegate respondsToSelector:@selector(projectValidationControllerDidCancel:)]) {
        [self.delegate projectValidationControllerDidCancel:self];
    }
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

@end
