//
//  ReseauxChauffageTableViewController.m
//  Commercial
//
//  Created by Benjamin Petit on 03/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "ReseauxChauffageTableViewController.h"
#import "ReseauCell.h"
#import "Reseau.h"
#import "Communicator.h"
#import "ReseauxRequest.h"
#import "Projet.h"
#import "ReseauChauffageEditionViewController.h"
#import "DeleteRequest.h"

@interface ReseauxChauffageTableViewController ()

@property (strong, nonatomic) NSArray *allProjects;

@end

@implementation ReseauxChauffageTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self importerDonnees];
}

- (void)importerDonnees
{

    NSMutableArray*listeCharge = [[NSMutableArray alloc] init];
    
    for(Reseau *res in self.reseaux)
    {
        [listeCharge addObject:res];
    }
    listeAffiche = listeCharge;
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return listeAffiche.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ReseauCell *cell = (ReseauCell *)[tableView dequeueReusableCellWithIdentifier:@"reseauCell" forIndexPath:indexPath];
    Reseau *r = [listeAffiche objectAtIndex:indexPath.row];
    cell.nameLabel.text = r.name;
    cell.existingLabel.text = [NSString stringWithFormat:@"Réseau %@", r.existing];
    cell.radiateursLabel.text = [NSString stringWithFormat:@"Emetteurs : %@", r.radiateurs];
    cell.materiauLabel.text = [NSString stringWithFormat:@"Réseau en %@", r.material];
    cell.diameterLabel.text = [NSString stringWithFormat:@"Diamètre : %@", r.diameter];
    return cell;
     
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Reseau *r = self.projet.reseauxChauffage[indexPath.row];
    self.statutReseau = @"EXISTE";
    [self performSegueWithIdentifier:@"editReseau" sender:r];
}

-(void)tableView:(UITableView*)tableView willBeginEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
    // peut rester vide
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // SUPPRIMER LIGNE
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        Reseau *reseau = [listeAffiche objectAtIndex:indexPath.row];
        NSString *identifiant = reseau.identifier;
        
        [listeAffiche removeObjectAtIndex:indexPath.row];
        
        DeleteRequest *request = [[DeleteRequest alloc] init];
        request.requete = [NSString stringWithFormat:@"DELETE FROM `envertlaevlt`.`reseaux_chantier` WHERE `reseaux_chantier`.`reseau_id` = %@", identifiant];
        Communicator *comm = [[Communicator alloc] init];
        [comm performRequest:request];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
        [self importerDonnees];
        [self.tableView reloadData];
        
    }
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"editReseau"]) {
        ReseauChauffageEditionViewController *dvc = [segue destinationViewController];
    
    if ([self.statutReseau isEqual: @"EXISTE"]) {
         NSInteger selectedIndex = [[self.tableView indexPathForSelectedRow] row];
        Reseau *reseauChoisi = [listeAffiche objectAtIndex:selectedIndex];
        dvc.reseau = reseauChoisi;
        dvc.reseau.statut = self.statutReseau;
    }
    
    if ([self.statutReseau isEqual: @"NOUVEAU"]) {
        
        Reseau *r = [[Reseau alloc] init];
        r.statut = @"NOUVEAU";
        r.existing = @"existant";
        r.radiateurs = @"radiateurs";
        r.material = @"cuivre";
        dvc.reseau = r;
    }
        dvc.projet = self.projet;
        dvc.nombreReseaux = self.reseaux.count;
    }

}

#pragma mark - UI Actions

- (IBAction)addReseau:(id)sender {
    self.statutReseau = @"NOUVEAU";
    [self performSegueWithIdentifier:@"editReseau" sender:nil];
}

@end
