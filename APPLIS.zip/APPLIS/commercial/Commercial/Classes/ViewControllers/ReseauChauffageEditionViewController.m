//
//  ReseauChauffageEditionViewController.m
//  Commercial
//
//  Created by Benjamin Petit on 17/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "ReseauChauffageEditionViewController.h"
#import "EditableTableViewCell.h"
#import "ReseauxRequest.h"
#import "Communicator.h"
#import "Projet.h"

@interface ReseauChauffageEditionViewController() <UITextFieldDelegate>

@property (strong, nonatomic) NSString *name;
@property (assign, nonatomic) BOOL exists;
@property (assign, nonatomic) BOOL emetteur;
@property (assign, nonatomic) BOOL materiau;
@property (strong, nonatomic) NSString *diameter;

@property (strong, nonatomic) EditableTableViewCell *diameterCell;
@property (strong, nonatomic) EditableTableViewCell *nomCell;

@end

@implementation ReseauChauffageEditionViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(validate:)];
    
    self.exists = 0;
    self.emetteur = 0;
    self.materiau = 0;
    
    if ([self.reseau.statut  isEqual: @"EXISTE"]) {
    self.exists = [self.reseau.existing  isEqual: @"existant"] ? 0 : 1;
    self.emetteur = [self.reseau.radiateurs isEqual: @"radiateurs"] ? 0 : 1;
    
    if ([self.reseau.material  isEqual: @"cuivre"]) {
        self.materiau = 0;
    }
    if ([self.reseau.material  isEqual: @"PER"]) {
        self.materiau = 1;
        }
    if ([self.reseau.material  isEqual: @"acier"]) {
        self.materiau = 2;
    }
    }
    
    [self.tableView reloadData];

}

#pragma mark - UITableViewControllerDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger count = 0;
    switch (section) {
        case 0:
            count = 1;
            break;
        case 1:
            count = 2;
            break;
        case 2:
            count = 2;
            break;
        case 3:
            count = 3;
            break;
        case 4:
            count = 1;
            break;
    }
    return count;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.tableView.frame), 30.0f)];
    view.backgroundColor = [UIColor lightGrayColor];
    return view;
}


- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.diameterCell.textField resignFirstResponder];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;
    switch (indexPath.section) {
        case 0:
            cell = [self tableView:tableView nomCellForRowAtIndexPath:indexPath];
            break;
            case 1:
            cell = [self tableView:tableView creationCellForRowAtIndexPath:indexPath];
            break;
            case 2:
            cell = [self tableView:tableView emetteurCellForRowAtIndexPath:indexPath];
            break;
            case 3:
            cell = [self tableView:tableView materiauCellForRowAtIndexPath:indexPath];
            break;
            case 4:
            cell = [self tableView:tableView diameterCellForRowAtIndexPath:indexPath];
            default:
            break;
    }
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView nomCellForRowAtIndexPath:(NSIndexPath *)indexPath {
    EditableTableViewCell *cell = (EditableTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"diameterCell"];
    cell.titleLabel.text = @"Nom";
    cell.textField.placeholder = @"Réseau";
    cell.textField.keyboardType = UIKeyboardTypeAlphabet;
    cell.textField.delegate = self;
    cell.textField.text = self.reseau.name;
    self.nomCell = cell;
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView creationCellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"choiceCell"];
    if (indexPath.row == 0) {
        cell.textLabel.text = @"Existant";
        cell.accessoryType = [self.reseau.existing  isEqual: @"existant"] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    } else {
        cell.textLabel.text = @"Non existant";
        cell.accessoryType = [self.reseau.existing  isEqual: @"a creer"] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    }
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView emetteurCellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"choiceCell"];
    if (indexPath.row == 0) {
        cell.textLabel.text = @"Radiateurs";
       cell.accessoryType = [self.reseau.radiateurs  isEqual: @"radiateurs"] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    } else {
        cell.textLabel.text = @"Plancher chauffant";
        cell.accessoryType = [self.reseau.radiateurs  isEqual: @"plancher chauffant"] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    }
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView materiauCellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"choiceCell"];
    if (indexPath.row == 0) {
        cell.textLabel.text = @"Cuivre";
        cell.accessoryType = [self.reseau.material  isEqual: @"cuivre"] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    } else if (indexPath.row == 1) {
        cell.textLabel.text = @"PER";
        cell.accessoryType = [self.reseau.material  isEqual: @"PER"] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    } else {
        cell.textLabel.text = @"Acier";
        cell.accessoryType = [self.reseau.material  isEqual: @"acier"] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    }
    return cell;
}


- (UITableViewCell *)tableView:(UITableView *)tableView diameterCellForRowAtIndexPath:(NSIndexPath *)indexPath {
    EditableTableViewCell *cell = (EditableTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"diameterCell"];
    cell.titleLabel.text = @"Diamètre";
    cell.textField.placeholder = @"28";
    cell.textField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    cell.textField.delegate = self;
    cell.textField.text = self.reseau.diameter;
    self.diameterCell = cell;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
  
    switch (indexPath.section) {
        case 1:
            self.exists = (int)indexPath.row;
            break;
        case 2:
            self.emetteur = (int)indexPath.row;
            break;
        case 3:
            self.materiau = (int)indexPath.row;
            break;
        default:
            break;
    }
    
    NSString * step1 = self.exists ? @"a creer" : @"existant";
    self.reseau.existing = step1;
    NSString * step2 = self.emetteur ? @"plancher chauffant" : @"radiateurs";
    self.reseau.radiateurs = step2;
    
    switch (self.materiau) {
        case 0:
            self.reseau.material = @"cuivre";
            break;
        case 1:
            self.reseau.material = @"PER";
            break;
      /*  case 2:
            self.reseau.material = @"acier";
            break; */
        default:
            break;
    }
    
    [self.tableView reloadData];
}

#pragma mark - UITextFieldDelegate


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidbeginEditing:(UITextField *)textField {
}

- (void)textFieldDidEndEditing:(UITextField *)textField {

    self.reseau.name = self.nomCell.textField.text;
    self.reseau.diameter = self.diameterCell.textField.text;
}


#pragma mark - UI Actions

- (void)validate:(id)sender {
    
    if (self.reseau.name == nil) {
        self.reseau.name = [NSString stringWithFormat:@"Réseau %i", self.nombreReseaux +1];
    }
    if (self.reseau.diameter == nil) {
        self.reseau.diameter = @"NC";
    }
    
    ReseauxRequest *request = [[ReseauxRequest alloc] init];
    request.projectID = self.projet.identifier;
    request.action = self.reseau.statut;
    request.reseauID = self.reseau.identifier;
    request.type = @"chauffage";
    request.nom = self.reseau.name;
    request.existe = self.reseau.existing;
    request.radiateur = self.reseau.radiateurs;
    request.cuivre = self.reseau.material;
    request.diametre = self.reseau.diameter;
    Communicator *comm = [[Communicator alloc] init];
    [comm performRequest:request];
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

@end
