//
//  COMZoneEditionViewController.m
//  Commercial
//
//  Created by Benjamin Petit on 28/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "COMZoneEditionViewController.h"
#import "EditableTableViewCell.h"
#import "ZonesRequest.h"
#import "Communicator.h"

@interface COMZoneEditionViewController () <UITextFieldDelegate>

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *volume;
@property (strong, nonatomic) NSString *isoMurs;
@property (strong, nonatomic) NSString *isoCombles;
@property (strong, nonatomic) NSString *isoRampants;
@property (strong, nonatomic) NSString *menuiseries;

@property (strong, nonatomic) EditableTableViewCell *nameCell;
@property (strong, nonatomic) EditableTableViewCell *volumeCell;
@property (strong, nonatomic) EditableTableViewCell *isoMursCell;
@property (strong, nonatomic) EditableTableViewCell *isoComblesCell;
@property (strong, nonatomic) EditableTableViewCell *isoRampantsCell;
@property (strong, nonatomic) EditableTableViewCell *menuiseriesCell;

@end

@implementation COMZoneEditionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"NOMBRE DE ZONES : %i", self.nombreZones);

    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(validate:)];
    
    self.name = self.zone.name;
    self.volume = self.zone.volume;
    self.isoMurs = self.zone.isoMurs;
    self.isoCombles = self.zone.isoCombles;
    self.isoRampants = self.zone.isoRampants;
    self.menuiseries = self.zone.menuiseries;
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    EditableTableViewCell *cell = (EditableTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"editableCell" forIndexPath:indexPath];
    
    switch (indexPath.row) {
        case 0:
        {
            cell.titleLabel.text = @"Nom";
            cell.textField.text = self.name;
            self.nameCell = cell;
        }
            break;
        case 1:
        {
            cell.titleLabel.text = @"Volume";
            cell.textField.text = self.volume;
            self.volumeCell = cell;
        }
            break;
        case 2:
        {
            cell.titleLabel.text = @"Iso. murs";
            cell.textField.text = self.isoMurs;
            self.isoMursCell = cell;
        }
            break;
        case 3:
        {
            cell.titleLabel.text = @"Iso. combles";
            cell.textField.text = self.isoCombles;
            self.isoComblesCell = cell;
        }
            break;
        case 4:
        {
            cell.titleLabel.text = @"Iso. rampants";
            cell.textField.text = self.isoRampants;
            self.isoRampantsCell = cell;
        }
            break;
        case 5:
        {
            cell.titleLabel.text = @"Menuiseries";
            cell.textField.text = self.menuiseries;
            self.menuiseriesCell = cell;
        }
            break;
            
        default:
            break;
    }
    
    cell.textField.delegate = self;
    
    
    return cell;
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField == self.nameCell.textField) {
        self.zone.name = textField.text;
    } else if (textField == self.volumeCell.textField) {
        self.zone.volume = textField.text;
    } else if (textField == self.isoMursCell.textField) {
        self.zone.isoMurs = textField.text;
    } else if (textField == self.isoComblesCell.textField) {
        self.zone.isoCombles = textField.text;
    } else if (textField == self.isoRampantsCell.textField) {
        self.zone.isoRampants = textField.text;
    } else if (textField == self.menuiseriesCell.textField) {
        self.zone.menuiseries = textField.text;
    }
}

#pragma mark - UI

- (void)validate:(id)sender {
    
    if (self.zone.name == nil) {
        self.zone.name = [NSString stringWithFormat:@"Zone %i", self.nombreZones +1];
    }
    if (self.zone.volume == nil) {
        self.zone.volume = @"NC";
    }
    if (self.zone.isoMurs == nil) {
        self.zone.isoMurs = @"NC";
    }
    if (self.zone.isoCombles == nil) {
        self.zone.isoCombles = @"NC";
    }
    if (self.zone.isoRampants == nil) {
        self.zone.isoRampants = @"NC";
    }
    if (self.zone.menuiseries == nil) {
        self.zone.menuiseries = @"NC";
    }
    
    ZonesRequest *request = [[ZonesRequest alloc] init];
    request.projectID = self.projet.identifier;
    request.action = self.zone.statut;
    request.zoneID = self.zone.identifier;
    request.nom = self.zone.name;
    request.volume = self.zone.volume;
    request.murs = self.zone.isoMurs;
    request.combles = self.zone.isoCombles;
    request.rampants = self.zone.isoRampants;
    request.menuiseries = self.zone.menuiseries;
   // Communicator *comm = [[Communicator alloc] init];
   // [comm performRequest:request];
    
    [self.navigationController popViewControllerAnimated:YES];
    
    /*
    
    self.zone.name = self.name;
    self.zone.volume = self.volume;
    self.zone.isoMurs = self.isoMurs;
    self.zone.isoCombles = self.isoCombles;
    self.zone.isoRampants = self.isoRampants;
    self.zone.menuiseries = self.menuiseries;
     
     */
    
}

@end
