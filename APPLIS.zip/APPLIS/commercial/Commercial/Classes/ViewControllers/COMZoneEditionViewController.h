//
//  COMZoneEditionViewController.h
//  Commercial
//
//  Created by Benjamin Petit on 28/11/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Projet.h"
#import "Zone.h"

@interface COMZoneEditionViewController : UITableViewController

@property (strong, nonatomic) Projet *projet;
@property (strong, nonatomic) Zone *zone;

@property (nonatomic, assign) int nombreZones;

@end
