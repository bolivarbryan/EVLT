//
//  UIColor+Palette.m
//  Commercial
//
//  Created by Benjamin Petit on 29/10/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "UIColor+Palette.h"

@implementation UIColor (Palette)

+ (UIColor *)accentColor {
    return [UIColor colorWithRed:(88/255.0f) green:(168/255.0f) blue:(81/255.0f) alpha:1.0f];
}

+ (UIColor *)navBarTextColor {
    return [UIColor whiteColor];
}

@end
