//
//  projetViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 30/01/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "projetViewController.h"
#import "nouveauProjetTableViewController.h"
#import "nouveauClientTableViewController.h"
#import "detailProjetViewController.h"
#import "Projet.h"
#import "Communicator.h"
#import "ClientProjectsRequest.h"
#import "Client.h"
#import "DeleteRequest.h"

@interface projetViewController () {
    NSMutableArray *_objects;
}
@end

@implementation projetViewController

// @synthesize client_id;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self importerDonnees];
    
    NSMutableArray*listeCharge = [[NSMutableArray alloc] init];
    
    for(Projet *projet in self.projets)
    {
            [listeCharge addObject:projet];
    }
    listeAffiche = listeCharge;
    
    NSSortDescriptor *mySorter = [[NSSortDescriptor alloc] initWithKey:@"type" ascending:YES];
    [listeAffiche sortUsingDescriptors:[NSArray arrayWithObject:mySorter]];
   
    [self.tableView reloadData];

}



- (void)importerDonnees
{
    ClientProjectsRequest *request = [[ClientProjectsRequest alloc] init];
    request.clientID = self.clientSelectionne;
    Communicator *communicator = [[Communicator alloc] init];
    self.projets = (NSArray *)[communicator performRequest:request];
}


- (void)viewWillAppear:(BOOL)animated {
 
    [super viewWillAppear:animated];
    [self importerDonnees];
    
    NSMutableArray*listeCharge = [[NSMutableArray alloc] init];
    
    for(Projet *projet in self.projets)
    {
        [listeCharge addObject:projet];
    }
    listeAffiche = listeCharge;
    
    NSSortDescriptor *mySorter = [[NSSortDescriptor alloc] initWithKey:@"type" ascending:YES];
    [listeAffiche sortUsingDescriptors:[NSArray arrayWithObject:mySorter]];
    
    [self.tableView reloadData];
}

- (void) viewDidAppear:(BOOL)animated
{
   /*
    
    //[self importerDonnees];
   // self.navigationController.toolbar.hidden = NO;
    [self.tableView reloadData];
    
    */
    
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //  return [listeClients count];
    return [listeAffiche count] + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row < [listeAffiche count]) {
        static NSString *CellIdentifier =@"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
        
        Projet *projet = [listeAffiche objectAtIndex:indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@", projet.type];
        cell.detailTextLabel.text = [Projet nameForStatus:projet.status];
        
        return cell;
    } else {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"newProjectCell" forIndexPath:indexPath];
        cell.textLabel.text = @"Nouveau projet";
        return cell;
    }
}


/*
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

-(void)tableView:(UITableView*)tableView willBeginEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
    // peut rester vide
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // SUPPRIMER LIGNE
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        Projet *projet = [listeAffiche objectAtIndex:indexPath.row];
        NSString *identifiant = projet.identifier;
        
        [listeAffiche removeObjectAtIndex:indexPath.row];
        
        DeleteRequest *request = [[DeleteRequest alloc] init];
        request.requete = [NSString stringWithFormat:@"DELETE FROM `envertlaevlt`.`chantier` WHERE `chantier`.`chantier_id` = %@", identifiant];
        Communicator *comm = [[Communicator alloc] init];
        [comm performRequest:request];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
        [self importerDonnees];
        [self.tableView reloadData];
        
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row >= [listeAffiche count]) {
        [self performSegueWithIdentifier:@"nouveauProjet" sender:nil];
    }
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
    }
}

/*
 - (void)someMethod {
 UIViewController *myController = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeController"];
 [self.navigationController pushViewController: myController animated:YES];
 }
 */

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"nouveauProjet"]) {
        UINavigationController *navController = [segue destinationViewController];
        nouveauProjetTableViewController *dvc = (nouveauProjetTableViewController *)[navController topViewController];
        dvc.clientSelectionne = (self.clientSelectionne);
    }
    
    if ([[segue identifier] isEqualToString:@"versDetailsProjet"]) {
        
        detailProjetViewController *dvc = [segue destinationViewController];
        NSInteger selectedIndex = [[self.tableView indexPathForSelectedRow] row];
        dvc.clientSelectionne = (self.clientSelectionne);
        Projet *projet = [listeAffiche objectAtIndex:selectedIndex];
        dvc.chantierSelectionne = projet.identifier;
        dvc.projet = projet;
        dvc.client = self.client;
    }
    
    if ([[segue identifier] isEqualToString:@"versDetailsClient"]) {
        
        nouveauClientTableViewController *dvc = [segue destinationViewController];
        dvc.client = self.client;
        dvc.statut = @"EXISTE";
        
    }
    
}

@end
