//
//  coordonneesChantierViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 04/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "coordonneesChantierViewController.h"
#import "CoordonneesProjectRequest.h"
#import "Communicator.h"

@interface coordonneesChantierViewController ()

@end

@implementation coordonneesChantierViewController
@synthesize numeroText;
@synthesize rueText;
@synthesize codePostalText;
@synthesize villeText;

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.numeroText.text = self.projet.numero;
    self.rueText.text = self.projet.rue;
    self.codePostalText.text = self.projet.code_postal;
    self.villeText.text = self.projet.ville;
    
    numeroText.delegate = self;
    rueText.delegate = self;
    codePostalText.delegate = self;
    villeText.delegate = self;
    
    [numeroText resignFirstResponder];
    [rueText resignFirstResponder];
    [codePostalText resignFirstResponder];
    [villeText resignFirstResponder];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];

}

-(void)dismissKeyboard {
    [numeroText resignFirstResponder];
    [rueText resignFirstResponder];
    [codePostalText resignFirstResponder];
    [villeText resignFirstResponder];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void) recupCoordonnees
{
    if(self.geocoder == nil)
    {
        self.geocoder = [[CLGeocoder alloc] init];
    }
    
    NSString *numero = self.numeroText.text;
    NSString *rue = self.rueText.text;
    NSString *codePostal = self.codePostalText.text;
    NSString *ville = self.villeText.text;
    
    if ([self.numeroText.text  isEqual: @"Numéro"]){numero = @"";}
    if ([self.numeroText.text  isEqual: @"0"]){numero = @"";}
    if ([self.rueText.text  isEqual: @"Rue"]){rue = @"";}
    if ([self.codePostalText.text  isEqual: @"Code Postal"]){codePostal = @"";}
    if ([self.codePostalText.text  isEqual: @"0"]){codePostal = @"";}
    if ([self.villeText.text  isEqual: @"Ville"]){ville = @"";}
    
    NSString *address = [NSString stringWithFormat:@"%@ %@ %@ %@", numero, rue, codePostal, ville];
    
    [self.geocoder geocodeAddressString:address completionHandler:^(NSArray *placemarks, NSError *error) {
        
        if(placemarks.count > 0)
        {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            self.latitude = [NSString stringWithFormat:@"%f", placemark.location.coordinate.latitude];
            self.longitude = [NSString stringWithFormat:@"%f", placemark.location.coordinate.longitude];
            
            [self envoi];
            
        }
        else if (error.domain == kCLErrorDomain)
        {
            switch (error.code)
            {
                case kCLErrorDenied:
                    NSLog(@"ACCES REFUSE");
                    [self envoi];
                    break;
                case kCLErrorNetwork:
                    NSLog(@"PAS DE RESEAU");
                    [self envoi];
                    break;
                case kCLErrorGeocodeFoundNoResult:
                    NSLog(@"PAS DE RESULTAT");
                    [self envoi];
                    break;
                default:
                    NSLog(@"ERREUR : %@", error.localizedDescription);
                    [self envoi];
                    break;
            }
        }
        else
        {
            NSLog(@"ERREUR : %@", error.localizedDescription);
            [self envoi];
        }
    }];
    
    
    
}

- (void) envoi {
    
    CoordonneesProjectRequest *request = [[CoordonneesProjectRequest alloc] init];
    request.projectID = self.projet.identifier;
    request.statut = @"FERME";
    request.numero = self.numeroText.text;
    request.rue = self.rueText.text;
    request.code_postal = self.codePostalText.text;
    request.ville = self.villeText.text;
    request.latitude = self.latitude;
    request.longitude = self.longitude;
    
    Communicator *comm = [[Communicator alloc] init];
    self.projet = (Projet *)[comm performRequest:request];
    
    self.projet.numero = self.numeroText.text;
    self.projet.rue = self.rueText.text;
    self.projet.code_postal = self.codePostalText.text;
    self.projet.ville = self.villeText.text;
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)boutonValider:(id)sender {
    [self recupCoordonnees];
}

- (IBAction)geolocalise:(id)sender {
    
}

@end
