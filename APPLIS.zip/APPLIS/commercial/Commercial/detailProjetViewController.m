//
//  detailProjetViewController.m
//  Commercial
//
//  Created by Emmanuel Levasseur on 03/02/2014.
//  Copyright (c) 2014 Emmanuel Levasseur. All rights reserved.
//

#import "detailProjetViewController.h"
#import "commentaireViewController.h"
#import "coordonneesChantierViewController.h"
#import "technicienProjetViewController.h"
#import "photosProjetViewController.h"
#import "tachesProjetViewController.h"
#import "dateInstallationViewController.h"
#import "Communicator.h"
#import "ProjectDetailRequest.h"
#import "ReseauxRequest.h"
#import "ZonesRequest.h"
#import "PhotosRequest.h"
#import "ReseauxChauffageTableViewController.h"
#import "ReseauxECSTableViewController.h"
#import "Reseau.h"
#import "Photo.h"
#import "Technician.h"
#import "StatutProjetTableViewController.h"
#import "zonesProjetViewController.h"

@interface detailProjetViewController ()

@end

@implementation detailProjetViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {

    [super viewWillAppear:animated];
    
    [self communication];
    
    [self updateUI];
    
    [self.projet.numberOfTime retain];
    [self.projet.unitOfTime retain];
}

- (void)communication {
    
 /*   dispatch_group_t serviceGroup = dispatch_group_create();
    
    dispatch_group_enter(serviceGroup);
    [configService startWithCompletion:^(ConfigResponse *results, NSError* error){
  
  */
    
    ProjectDetailRequest *request = [[ProjectDetailRequest alloc] init];
    request.projectID = self.projet.identifier;
    Communicator *comm = [[Communicator alloc] init];
    self.projet = (Projet *)[comm performRequest:request];
    
    ZonesRequest *request2 = [[ZonesRequest alloc] init];
    request2.projectID = self.projet.identifier;
    request2.action = @"OUVRE";
    Communicator *c2 = [[Communicator alloc] init];
    self.zones = (NSArray *)[c2 performRequest:request2];
  
    ReseauxRequest *request3 = [[ReseauxRequest alloc] init];
    request3.projectID = self.projet.identifier;
    request3.action = @"OUVRE";
    Communicator *c3 = [[Communicator alloc] init];
    self.reseaux = (NSArray *)[c3 performRequest:request3];
    
    PhotosRequest *request4 = [[PhotosRequest alloc] init];
    request4.projectID = self.projet.identifier;
    request4.statut = @"OUVRE";
    Communicator *c4 = [[Communicator alloc] init];
    self.photos = (NSArray *)[c4 performRequest:request4];
    
    // affecter les réseaux au projet
    NSPredicate *chauffagePredicate = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        Reseau *r = (Reseau *)evaluatedObject;
        return r.type == ReseauTypeChauffage;
    }];
    NSPredicate *ecsPredicate = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        Reseau *r = (Reseau *)evaluatedObject;
        return r.type == ReseauTypeECS;
    }];
    self.projet.reseauxChauffage = [self.reseaux filteredArrayUsingPredicate:chauffagePredicate];
    self.projet.reseauxECS = [self.reseaux filteredArrayUsingPredicate:ecsPredicate];
   
}

// DEBUT DROPBOX
// DEBUT DROPBOX
// DEBUT DROPBOX
// DEBUT DROPBOX

- (void)testDropBox
{
    NSString *tmpJpegFile = [NSTemporaryDirectory() stringByAppendingPathComponent:@"Temp.jpeg"];
    NSString *destDir = @"/";
    NSString *filename = [NSString stringWithFormat:@"#%@.jpeg", self.projet.identifier];
    [[self restClient] uploadFile:filename toPath:destDir
                    withParentRev:nil fromPath:tmpJpegFile];
}

- (void)restClient:(DBRestClient *)client uploadedFile:(NSString *)destPath
              from:(NSString *)srcPath metadata:(DBMetadata *)metadata {
    NSLog(@"File uploaded successfully to path: %@", metadata.path);
}

- (void)restClient:(DBRestClient *)client uploadFileFailedWithError:(NSError *)error {
    NSLog(@"File upload failed with error: %@", error);
}

- (void)finishedUploadFile
{
    NSLog(@"Uploaded successfully.");
}

- (void)failedToUploadFile:(NSString*)withMessage
{
    NSLog(@"Failed to upload error is %@",withMessage);
}

// FIN DROPBOX
// FIN DROPBOX
// FIN DROPBOX
// FIN DROPBOX

- (void)updateUI {
    
    // Address
    NSMutableArray *addressArray = [NSMutableArray array];
    if (self.projet.numero) {
        [addressArray addObject:self.projet.numero];
    }
    if (self.projet.rue) {
        [addressArray addObject:self.projet.rue];
    }
    
    NSMutableArray *cityArray = [NSMutableArray array];
    if (self.projet.code_postal) {
        [cityArray addObject:self.projet.code_postal];
    }
    if (self.projet.ville) {
        [cityArray addObject:self.projet.ville];
    }
    
    NSMutableArray *contactArray = [NSMutableArray array];
    if (self.client.mobilePhone) {
        if ([self.client.mobilePhone isEqualToString:@""])
        {
        }
        else
        {
         [contactArray addObject:self.client.mobilePhone];
        }
    }
    if (self.client.phone) {
        if ([self.client.phone isEqualToString:@""])
        {
        }
        else
        {
        [contactArray addObject:self.client.phone];
        }
    }
    if (self.client.email) {
        if ([self.client.email isEqualToString:@""])
        {
        }
        else
        {
        [contactArray addObject:self.client.email];
        }
    }

    NSString *adresse1 = [addressArray componentsJoinedByString:@", "];
    NSString *adresse2 = [cityArray componentsJoinedByString:@", "];
    NSString *adresse3 = [contactArray componentsJoinedByString:@", "];
    
    if ((adresse1.length == 0) && (adresse2.length == 0)) {
        self.addressCell.streetLabel.text = @"Aucune adresse renseignée";
        self.addressCell.cityLabel.text = @"";
        self.addressCell.contactLabel.text = @"";
    } else {
        self.addressCell.streetLabel.text = adresse1;
        self.addressCell.cityLabel.text = adresse2;
        self.addressCell.contactLabel.text = adresse3;
    }
    
    NSString *nbZones;
    nbZones = @"zone";
    if (self.zones.count > 1) {
        nbZones =@"zones";
    }
    
    NSString *nbReseauxChauffage;
    nbReseauxChauffage = @"réseau";
    if (self.projet.reseauxChauffage.count > 1) {
        nbReseauxChauffage =@"réseaux";
    }
    
    NSString *nbReseauxECS;
    nbReseauxECS = @"réseau";
    if (self.projet.reseauxECS.count > 1) {
        nbReseauxECS =@"réseaux";
    }
    
    NSString *nbPhotos;
    nbPhotos = @"photo";
    if (self.photos.count > 1) {
        nbPhotos =@"photos";
    }
    
    self.zoneCell.textLabel.text = [NSString stringWithFormat:@"%li %@", (unsigned long)self.zones.count, nbZones];
    self.heatingCell.textLabel.text = [NSString stringWithFormat:@"%li %@ de chauffage", (unsigned long)self.projet.reseauxChauffage.count, nbReseauxChauffage];
    self.waterCell.textLabel.text = [NSString stringWithFormat:@"%li %@ ECS", (unsigned long)self.projet.reseauxECS.count, nbReseauxECS];
    
    self.photoCell.textLabel.text = [NSString stringWithFormat:@"%li %@", (unsigned long)self.photos.count, nbPhotos];
    self.commCell.textLabel.text = self.projet.note;
    
    // Date
    NSString *days = nil;
    NSString *date = nil;
    NSString *unite = nil;
    float number = [self.projet.numberOfTime floatValue];
    
    if ([self.projet.unitOfTime isEqual:@"Heure(s)"]) {
        if (number < 2) {
            unite = @"heure";
        } else {
            unite = @"heures";
        }
    }
    
    if ([self.projet.unitOfTime isEqual:@"Jour(s)"]) {
        if (number < 2) {
            unite = @"jour";
        } else {
            unite = @"jours";
        }
    }
    
    if ([self.projet.unitOfTime isEqual:@"Semaine(s)"]) {
        if (number < 2) {
            unite = @"semaine";
        } else {
            unite = @"semaines";
        }
    }

    self.duree = [self.projet.numberOfTime doubleValue];
    days = [NSString stringWithFormat:@"%.1f %@", self.duree, unite];
    
    if (self.projet.startDate) {
        NSDateFormatter *f = [[NSDateFormatter alloc] init];
        f.locale = [NSLocale localeWithLocaleIdentifier:@"FR_fr"];
        f.dateStyle = NSDateFormatterShortStyle;
        NSString *dateString = [f stringFromDate:self.projet.startDate];
        date = [NSString stringWithFormat:@"%@ à partir du %@", days, dateString];
    } else {
        date = days;
    }
    self.dateCell.textLabel.text = date;
    
    NSString *actif =@"NON";
    // VOIR POUR COMPTER TECHS ACTIFS
    NSMutableArray *techArray = [NSMutableArray array];
    if ([self.projet.gaetan  isEqual: @"oui"]) {
        [techArray addObject:@"Gaëtan"];
        actif = @"OUI";
    }
    if ([self.projet.fred  isEqual: @"oui"]) {
        [techArray addObject:@"Fred"];
        actif = @"OUI";
    }
    if ([self.projet.denis  isEqual: @"oui"]) {
        [techArray addObject:@"Denis"];
        actif = @"OUI";
    }
    if ([self.projet.vincent  isEqual: @"oui"]) {
        [techArray addObject:@"Vincent"];
        actif = @"OUI";
    }
    
    // TROP COOL
    NSString *tech = @"Pas de technicien sélectionné";
    
    if ([actif  isEqual: @"OUI"]) {
        tech = [techArray componentsJoinedByString:@", "];
    }

    
    self.techCell.textLabel.text = tech;

    self.statusCell.textLabel.text = self.projet.statutComplet;
    
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"versCommentaireProjet"]) {
        commentaireViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
    }
    
    if ([[segue identifier] isEqualToString:@"versCoordonneesChantier"]) {
        coordonneesChantierViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
    }
    
    if ([[segue identifier] isEqualToString:@"versTechnicienProjet"]) {
        technicienProjetViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
    }
    if ([[segue identifier] isEqualToString:@"versStatutProjet"]) {
        StatutProjetTableViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
    }
    if ([[segue identifier] isEqualToString:@"versPhotoProjet"]) {
        photosProjetViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
        dvc.photos = self.photos;
    }
    
    if ([[segue identifier] isEqualToString:@"versTacheProjet"]) {
        tachesProjetViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
    }
    
    if ([[segue identifier] isEqualToString:@"versDateProjet"]) {
        dateInstallationViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
    }
    
    if ([[segue identifier] isEqualToString:@"versReseauxChauffage"]) {
        ReseauxChauffageTableViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
        dvc.reseaux = self.projet.reseauxChauffage;
    }
    
    if ([[segue identifier] isEqualToString:@"versReseauxECS"]) {
        ReseauxECSTableViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
        dvc.reseaux = self.projet.reseauxECS;
    }
    
    if ([[segue identifier] isEqualToString:@"versZones"]) {
        zonesProjetViewController *dvc = [segue destinationViewController];
        dvc.projet = self.projet;
        dvc.zones = self.zones;
    }
    
}


@end
