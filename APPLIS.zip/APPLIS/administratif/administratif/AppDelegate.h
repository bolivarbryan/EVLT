//
//  AppDelegate.h
//  administratif
//
//  Created by Emmanuel Levasseur on 18/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TechnicianStore.h"
#import "TECProjectManager.h"
#import "Client.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (weak, nonatomic) Client *clientActif;

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) TechnicianStore *technicianStore;
@property (strong, nonatomic) TECProjectManager *projectManager;

@property (strong, nonatomic) NSArray *projets;
@property (strong, nonatomic) NSArray *clients;
@property (strong, nonatomic) NSArray *coords;
@property (strong, nonatomic) NSArray *clientsCoords;
@property (strong, nonatomic) NSMutableArray *paiementsClient;



@end

