//
//  Paiement.h
//  administratif
//
//  Created by Emmanuel Levasseur on 19/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Paiement : NSObject

@property (strong, nonatomic) NSString *identifier;
@property (strong, nonatomic) NSString* montant;
@property (strong, nonatomic) NSDate *date;
@property (strong, nonatomic) NSString* mode;
@property (strong, nonatomic) NSString* info;

@end
