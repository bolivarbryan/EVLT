//
//  ProjetJourCell.m
//  Technicien
//
//  Created by Emmanuel Levasseur on 17/05/2015.
//  Copyright (c) 2015 En Vert La Terre. All rights reserved.
//

#import "ProjetJourCell.h"

@implementation ProjetJourCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
