//
//  programmationCell.h
//  administratif
//
//  Created by Emmanuel Levasseur on 18/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface programmationCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *nomLabel;
@property (weak, nonatomic) IBOutlet UILabel *typeLabel;

@property (weak, nonatomic) IBOutlet UIImageView *portableImage;
@property (weak, nonatomic) IBOutlet UIImageView *mailImage;
@property (weak, nonatomic) IBOutlet UIImageView *portableActif;
@property (weak, nonatomic) IBOutlet UIImageView *mailActif;

@end
