//
//  encaissementsCell.h
//  administratif
//
//  Created by Emmanuel Levasseur on 19/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface encaissementsCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *nomLabel;

@property (weak, nonatomic) IBOutlet UILabel *montantInitial;
@property (weak, nonatomic) IBOutlet UILabel *plusValues;
@property (weak, nonatomic) IBOutlet UILabel *moinsValues;
@property (weak, nonatomic) IBOutlet UILabel *totalHT;
@property (weak, nonatomic) IBOutlet UILabel *totalTTC;
@property (weak, nonatomic) IBOutlet UILabel *totalPaye;
@property (weak, nonatomic) IBOutlet UILabel *resteAPayer;
@property (weak, nonatomic) IBOutlet UILabel *resteExigible;

@property (weak, nonatomic) IBOutlet UIButton *paiementBouton;


@end
