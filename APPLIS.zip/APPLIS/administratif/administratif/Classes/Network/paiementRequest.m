//
//  requetePrecise.m
//  administratif
//
//  Created by Emmanuel Levasseur on 27/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "paiementRequest.h"

@implementation paiementRequest

- (NSString *)postArguments {
    return [NSString stringWithFormat:@"client_id=%@&statut=%@&montant=%@&date=%@&mode=%@&info=%@", self.clientID, self.statut, self.montant, self.date, self.mode, self.info];
}

- (NSString *)serviceEndpoint {
    return @"paiement_projet.php";
}


@end
