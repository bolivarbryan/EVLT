//
//  AllPaiementsListRequest.h
//  administratif
//
//  Created by Emmanuel Levasseur on 19/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "AbstractRequest.h"

@interface AllPaiementsListRequest : AbstractRequest

@property (strong, nonatomic) NSString *statut;

@end
