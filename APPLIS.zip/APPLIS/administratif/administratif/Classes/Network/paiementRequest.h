//
//  requetePrecise.h
//  administratif
//
//  Created by Emmanuel Levasseur on 27/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "AbstractRequest.h"

@interface paiementRequest : AbstractRequest

@property (strong, nonatomic) NSString *statut;
@property (strong, nonatomic) NSString *montant;
@property (strong, nonatomic) NSString *date;
@property (strong, nonatomic) NSString *mode;
@property (strong, nonatomic) NSString *info;
@property (strong, nonatomic) NSString *clientID;

@end
