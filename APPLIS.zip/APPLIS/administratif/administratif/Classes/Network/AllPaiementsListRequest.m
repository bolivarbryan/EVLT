//
//  AllPaiementsListRequest.m
//  administratif
//
//  Created by Emmanuel Levasseur on 19/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "AllPaiementsListRequest.h"
#import "Paiement.h"

@implementation AllPaiementsListRequest

- (NSString *)postArguments {
    return [NSString stringWithFormat:@"statut_id=%@", self.statut];
}

- (NSString *)serviceEndpoint {
    return @"import_allPaiements.php";
}


- (id)parseObject:(id)object {
    NSMutableArray *paiements = [NSMutableArray array];
    if (object && [object isKindOfClass:[NSArray class]]) {
        NSArray *jsonArray = (NSArray *)object;
        for (NSDictionary *projectDetail in jsonArray) {
            Paiement *paiement = [Paiement new];
            paiement.identifier = projectDetail[@"client_id"];
            paiement.montant = projectDetail[@"montant"];
            paiement.date = projectDetail[@"date"];
            paiement.mode = projectDetail[@"mode"];
            paiement.info = projectDetail[@"info"];
            
            [paiements addObject:paiement];
        }
    }
    
    return paiements;
}

@end
