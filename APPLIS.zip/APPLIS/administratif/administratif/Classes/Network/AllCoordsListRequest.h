//
//  AllCoordsListRequest.h
//  Technicien
//
//  Created by Emmanuel Levasseur on 15/05/2015.
//  Copyright (c) 2015 En Vert La Terre. All rights reserved.
//

#import "AbstractRequest.h"

@interface AllCoordsListRequest : AbstractRequest

@property (strong, nonatomic) NSString *statut;

@end

