
//
//  AllPrixListRequest.m
//  administratif
//
//  Created by Emmanuel Levasseur on 19/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "AllPrixListRequest.h"
#import "Projet.h"

@implementation AllPrixListRequest

- (NSString *)postArguments {
    return [NSString stringWithFormat:@"statut_id=%@", self.statut];
}

- (NSString *)serviceEndpoint {
    return @"import_allPrix.php";
}


- (id)parseObject:(id)object {
    NSMutableArray *projets = [NSMutableArray array];
    if (object && [object isKindOfClass:[NSArray class]]) {
        NSArray *jsonArray = (NSArray *)object;
        for (NSDictionary *projectDetail in jsonArray) {
            Projet *projet = [Projet new];
            projet.identifier = projectDetail[@"chantier_id"];
            projet.prix = projectDetail[@"prix_ht"];
            projet.tva = projectDetail[@"tva"];
            projet.exigible = projectDetail[@"pourcentage_exigible"];
            projet.statutPaiement = projectDetail[@"statut_paiement"];
            projet.plusValues = projectDetail[@"plus_values"];
            projet.moinsValues = projectDetail[@"moins_values"];
            
            [projets addObject:projet];
        }
    }
    
    return projets;
}

@end
