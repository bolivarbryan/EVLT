//
//  detailPaiementsTableViewController.h
//  administratif
//
//  Created by Emmanuel Levasseur on 01/06/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Client.h"

@interface detailPaiementsTableViewController : UITableViewController

@property (weak, nonatomic) Client *client;

@property (strong, nonatomic) NSMutableArray *paiementsClient;

@end
