//
//  encaissementsTableViewController.m
//  administratif
//
//  Created by Emmanuel Levasseur on 19/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "encaissementsTableViewController.h"
#import "paiementViewController.h"
#import "detailPaiementsTableViewController.h"
#import "Communicator.h"
#import "AllPrixListRequest.h"
#import "AllPaiementsListRequest.h"

#import "AppDelegate.h"

#import "Projet.h"
#import "Client.h"
#import "Paiement.h"

#import "encaissementsCell.h"


@implementation encaissementsTableViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self importerDonnees];
    
    [self tri];
    
}

/*
-(void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [self importerDonnees];
    
    [self tri];
}
*/

- (void)importerDonnees {
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    clients = delegate.clients;
    projets = delegate.projets;
    
    AllPrixListRequest *request = [[AllPrixListRequest alloc] init];
    Communicator *c = [[Communicator alloc] init];
    self.allPrix = (NSMutableArray *)[c performRequest:request];
    
    AllPaiementsListRequest *request2 = [[AllPaiementsListRequest alloc] init];
    Communicator *c2 = [[Communicator alloc] init];
    self.allPaiements = (NSMutableArray *)[c2 performRequest:request2];
    
}

- (void)tri {
    
    NSMutableSet *selectedProjects = [NSMutableSet set];
    
    for (Projet *p in self.allPrix) {
        if ([p.statutPaiement isEqualToString:@"en cours"]) {
            [selectedProjects addObject:p];
        }
    }
    self.projetsASolder = [[selectedProjects allObjects] mutableCopy];
    
    for (Projet *p in self.projetsASolder) {
        Projet *p2 = [self projectId:p.identifier];
        p.clientID = p2.clientID;
    }
    
    NSMutableSet *selectedClients = [NSMutableSet set];

    for (Client *c in clients) {
        Projet *p = [self projectWithId:c.identifier];
        if ([self.projetsASolder containsObject:p]){
            [selectedClients addObject:c];
        }
    }
    self.clientsASolder = [[selectedClients allObjects] mutableCopy];
}

- (Projet *)projectId:(NSString *)identifier {
    for (Projet *p in projets) {
        if ([p.identifier isEqualToString:identifier]) {
            return p;
        }
    }
    return nil;
}

- (Projet *)projectWithId:(NSString *)identifier {
    for (Projet *p in self.projetsASolder) {
        if ([p.clientID isEqualToString:identifier]) {
            return p;
        }
    }
    return nil;
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
  
     return [self.clientsASolder count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    encaissementsCell *cell = (encaissementsCell *)[tableView dequeueReusableCellWithIdentifier:@"encaissementsCell" forIndexPath:indexPath];
    
    cell.paiementBouton.tag = indexPath.row;
    [cell.paiementBouton addTarget:self action:@selector(boutonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
     Client *c = [self.clientsASolder objectAtIndex:indexPath.row];
    cell.nomLabel.text = [NSString stringWithFormat:@"%@ %@", c.firstName, c.lastName];
    
    float montantTotal = 0;
    float plusValuesTotal = 0;
    float plusValuesTotalTTC = 0;
    float moinsValuesTotalTTC = 0;
    float moinsValuesTotal = 0;
    float montantTotalHT = 0;
    float montantTotalTTC = 0;
    float totalPaye = 0;
    float totalExigible = 0;
    
    float totalPayeProjet = 0;
    
    for (Paiement *p2 in self.allPaiements) {
        if ([p2.identifier isEqualToString:c.identifier]) {
            float montantPaye = [p2.montant floatValue];
            totalPayeProjet = totalPayeProjet + montantPaye;
        }
    }
    
    totalPaye = totalPaye + totalPayeProjet;
    
    for (Projet *p in self.projetsASolder) {
        if ([p.clientID isEqualToString:c.identifier]) {
            float montantProjet = [p.prix floatValue];
            float plusValuesProjet = [p.plusValues floatValue];
            float moinsValuesProjet = [p.moinsValues floatValue];
            float montantProjetHT = [p.prix floatValue];
            float tvaProjet = [p.tva floatValue];
            float poucentageExigible = [p.exigible floatValue];
            float montantProjetTTC = montantProjetHT * (1 + (tvaProjet/100));
            
            montantTotal = montantTotal + montantProjet;
            plusValuesTotal = plusValuesTotal + plusValuesProjet;
            plusValuesTotalTTC = plusValuesTotal * (1 + (tvaProjet/100));
            moinsValuesTotal = moinsValuesTotal + moinsValuesProjet;
            moinsValuesTotalTTC = moinsValuesTotal * (1 + (tvaProjet/100));
            montantTotalHT = montantTotalHT + montantProjetHT;
            montantTotalTTC = montantTotalTTC + montantProjetTTC;
            
            float totalExigibleProjet = montantProjetTTC *  (poucentageExigible/100);
            
            totalExigible = totalExigible + totalExigibleProjet + plusValuesTotalTTC - moinsValuesTotalTTC;
        }
        
      
    }
    
    float resteAPayer = montantTotalTTC - totalPaye;
    
    montantTotalHT = montantTotalHT + plusValuesTotal - moinsValuesTotal;
    montantTotalTTC = montantTotalTTC + plusValuesTotalTTC - moinsValuesTotalTTC;
    
    cell.montantInitial.text = [NSString stringWithFormat:@"%.2f €",montantTotal];
    cell.plusValues.text = [NSString stringWithFormat:@"%.2f €",plusValuesTotal];
    cell.moinsValues.text = [NSString stringWithFormat:@"%.2f €",moinsValuesTotal];
    cell.totalHT.text = [NSString stringWithFormat:@"%.2f €",montantTotalHT];
    cell.totalTTC.text = [NSString stringWithFormat:@"%.2f €",montantTotalTTC];
    cell.totalPaye.text = [NSString stringWithFormat:@"%.2f €",totalPaye];
    cell.resteAPayer.text = [NSString stringWithFormat:@"%.2f €",resteAPayer];
    float resteExigible = 0;
    if (totalExigible > totalPaye) {
        resteExigible = totalExigible - totalPaye;
    }
    cell.resteExigible.text = [NSString stringWithFormat:@"%.2f €",resteExigible];
    
    self.totalExigibleTousProjets = self.totalExigibleTousProjets + resteExigible;
    
    self.navigationItem.title = [NSString stringWithFormat: @"Encaissements - Total exigible : %.2f €", self.totalExigibleTousProjets];
    
    return cell;
    
}

-(void)boutonClicked:(UIButton*)sender
{
    NSInteger selectedIndex = (long)sender.tag;
    self.clientActif = [self.clientsASolder objectAtIndex:selectedIndex];
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    delegate.clientActif = self.clientActif;
}

#pragma mark - Table view delegate methods

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    NSInteger selectedIndex = indexPath.row;
    self.clientActif = [self.clientsASolder objectAtIndex:selectedIndex];
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    delegate.clientActif = self.clientActif;
    
    self.paiementsClient= [[NSMutableArray alloc] init];
    
    for (Paiement *p in self.allPaiements) {
        if ([p.identifier isEqualToString:self.clientActif.identifier]) {
            [self.paiementsClient addObject:p];
        }
    }
    delegate.paiementsClient = self.paiementsClient;
    
}



@end
