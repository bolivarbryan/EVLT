//
//  encaissementsTableViewController.h
//  administratif
//
//  Created by Emmanuel Levasseur on 19/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Client.h"

@interface encaissementsTableViewController : UITableViewController{
    NSArray *clients;
    NSArray *projets;
    NSMutableArray *listeAffiche;
}

@property (weak, nonatomic) Client *clientActif;

@property (strong, nonatomic) NSMutableArray *allPrix;
@property (strong, nonatomic) NSMutableArray *allPaiements;
@property (strong, nonatomic) NSMutableArray *paiementsClient;
@property (strong, nonatomic) NSMutableArray *projetsASolder;
@property (strong, nonatomic) NSMutableArray *clientsASolder;
@property (assign, nonatomic) float totalExigibleTousProjets;

@end
