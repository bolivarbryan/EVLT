//
//  MasterViewController.h
//  administratif
//
//  Created by Emmanuel Levasseur on 18/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BadgeLabel.h"

@interface MasterViewController : UITableViewController{
    NSArray *clients;
    NSArray *projets;
}

@property (strong, nonatomic) NSMutableArray *chantierAProgrammer;
@property (strong, nonatomic) NSMutableArray *chantierEnCoursProg;
@property (strong, nonatomic) NSMutableArray *chantierPrevu;

@property (weak, nonatomic) IBOutlet BadgeLabel *badgeProgrammation;

- (IBAction)programmationBouton:(id)sender;


- (IBAction)testPass:(id)sender;


@end
