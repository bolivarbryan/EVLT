//
//  programmationTableViewController.m
//  administratif
//
//  Created by Emmanuel Levasseur on 18/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <MessageUI/MessageUI.h>

#import "programmationTableViewController.h"

#import "AppDelegate.h"

#import "programmationCell.h"

#import "Projet.h"
#import "Client.h"


@interface programmationTableViewController () <MFMessageComposeViewControllerDelegate>

@end

@implementation programmationTableViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    clients = delegate.clients;
    clientsCoords = delegate.clientsCoords;
    
    [self ajoutSegmentedControl];
    
    listeAffiche = self.aProgrammer;
    
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [listeAffiche count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    programmationCell *cell = (programmationCell *)[tableView dequeueReusableCellWithIdentifier:@"programmationCell" forIndexPath:indexPath];
    
    Projet *p = [listeAffiche objectAtIndex:indexPath.row];
    
    NSMutableSet *selectedClients = [NSMutableSet set];
    Client *client = [self clientWithId:p.clientID];
    [selectedClients addObject:client];
  //  NSLog(@"CLIENT : %@", client);
    transit = [[selectedClients allObjects] mutableCopy];
    Client *c = [transit objectAtIndex:0];
    [transit removeAllObjects];
    
    cell.nomLabel.text = [NSString stringWithFormat:@"%@ %@", c.lastName, c.firstName];
    cell.typeLabel.text = p.type;
    
    cell.portableImage.hidden = YES;
    cell.portableActif.hidden = YES;
    cell.mailImage.hidden = YES;
    cell.mailActif.hidden = YES;
    
        if ([p.contact isEqualToString:@"sms"]) {
            cell.portableImage.hidden = NO;
            cell.portableActif.hidden = NO;
            cell.mailImage.hidden = NO;
            cell.mailActif.hidden = NO;
            cell.portableActif.image = [UIImage imageNamed:@"valider.png"];
            cell.mailActif.image = [UIImage imageNamed:@"annuler.png"];
        }
        if ([p.contact isEqualToString:@"mail"]) {
            cell.portableImage.hidden = NO;
            cell.portableActif.hidden = NO;
            cell.mailImage.hidden = NO;
            cell.mailActif.hidden = NO;
            cell.mailActif.image = [UIImage imageNamed:@"valider.png"];
            cell.portableActif.image = [UIImage imageNamed:@"annuler.png"];
        }
        if ([p.contact isEqualToString:@"sms + mail"]) {
            cell.portableImage.hidden = NO;
            cell.portableActif.hidden = NO;
            cell.mailImage.hidden = NO;
            cell.mailActif.hidden = NO;
            cell.mailActif.image = [UIImage imageNamed:@"valider.png"];
            cell.portableActif.image = [UIImage imageNamed:@"valider.png"];
        }
    
    return cell;

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    Projet *p = [listeAffiche objectAtIndex:indexPath.row];
    
    NSMutableSet *selectedClients = [NSMutableSet set];
    Client *client = [self clientCoordsWithId:p.clientID];
    [selectedClients addObject:client];

    transit = [[selectedClients allObjects] mutableCopy];
    Client *c = [transit objectAtIndex:0];
    self.clientAContacter = c;
    
    [self alertShow];
    
}

- (void) alertShow  {
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"CHOISIR UN MODE DE CONTACT" message:@"Choisir une option" delegate:self cancelButtonTitle:@"Annuler" otherButtonTitles:@"MAIL",@"SMS",@"SMS + MAIL", nil];
    [alertView show];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (buttonIndex == 1) {
        [self testMail];
    }
    if (buttonIndex == 2) {
        [self testNum];
    }
    if (buttonIndex == 3) {
        [self testMail];
        [self testNum];
    }
    
}

- (void) testMail {
    
    
    BOOL test = [self validateEmail:self.clientAContacter.email];
    if (test == YES) {
        [self envoiMail];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Oups" message:@"Pas d'adresse mail valide" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}

- (BOOL) validateEmail: (NSString *) candidate {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:candidate];
}

- (void) envoiMail {
    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
  //  controller.mailComposeDelegate = self;
    [controller setToRecipients:[NSArray arrayWithObject:self.clientAContacter.email]];
    [controller setSubject:@"Votre installation EN VERT LA TERRE"];
    [controller setMessageBody:@"Corps du message" isHTML:NO];
    [self presentViewController:controller animated:YES completion:nil];
}

- (void) testNum {
    NSArray* words = [self.clientAContacter.mobilePhone componentsSeparatedByCharactersInSet :[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString* nospacestring = [words componentsJoinedByString:@""];
    NSMutableString *result=[NSMutableString stringWithFormat:@"%.2lu", (unsigned long)nospacestring.length];
    NSCharacterSet *_NumericOnly = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *myStringSet = [NSCharacterSet characterSetWithCharactersInString:nospacestring];
    
    if ([_NumericOnly isSupersetOfSet: myStringSet]) {
        
        if ([result isEqualToString:@"10"]) {
            [self envoiTexto];
        }
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Oups" message:@"Pas de numéro de portable valide" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}

- (void) envoiTexto {
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    
    if([MFMessageComposeViewController canSendText])
    {
        controller.body = @"Coucou, c'est un test d'envoi depuis mon appli";
        controller.recipients = [NSArray arrayWithObjects:self.clientAContacter.mobilePhone, nil];
        controller.messageComposeDelegate = self;
        //ACTIVER LIGNE POUR ENVOI TEXTO
    //    [self presentViewController:controller animated:YES completion:nil];
    }
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
    
    switch (result) {
        case MessageComposeResultCancelled:
            NSLog(@"Cancelled");
            break;
        case MessageComposeResultFailed:
            NSLog(@"Failed");
            break;
        case MessageComposeResultSent:
            NSLog(@"Send");
            break;
        default:
            break;
    }
    
    [self dismissViewControllerAnimated:NO completion:nil];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    
    if (result == MFMailComposeResultSent) {
        NSLog(@"It's away!");
    }
    [self dismissViewControllerAnimated:NO completion:nil];
}

- (Client *)clientWithId:(NSString *)identifier {
    for (Client *c in clients) {
        if ([c.identifier isEqualToString:identifier]) {
            return c;
        }
    }
    return nil;
}

- (Client *)clientCoordsWithId:(NSString *)identifier {
    for (Client *c in clientsCoords) {
        if ([c.identifier isEqualToString:identifier]) {
            return c;
        }
    }
    return nil;
}

- (void)ajoutSegmentedControl {
   
    NSArray *segItemsArray = [NSArray arrayWithObjects: @"A programmer", @"Prog. en cours", @"Prevu", nil];
  
    UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:segItemsArray];
    segmentedControl.frame = CGRectMake(0, 0, 300, 30);
    segmentedControl.selectedSegmentIndex = 0;
    [segmentedControl addTarget:self action:@selector(MySegmentControlAction:) forControlEvents: UIControlEventValueChanged];
    segmentedControl.selectedSegmentIndex = 0;
    
    UIBarButtonItem *segmentedControlButtonItem = [[UIBarButtonItem alloc] initWithCustomView:(UIView *)segmentedControl];
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:@selector(MySegmentControlAction:)];
    NSArray *barArray = [NSArray arrayWithObjects: flexibleSpace, segmentedControlButtonItem, flexibleSpace, nil];
    
    [self setToolbarItems:barArray];
    
}

- (void)MySegmentControlAction:(UISegmentedControl *)segment
{
    if(segment.selectedSegmentIndex == 0)
    {
        listeAffiche = self.aProgrammer;
    }
    if(segment.selectedSegmentIndex == 1)
    {
        listeAffiche = self.progEnCours;
    }
    if(segment.selectedSegmentIndex == 2)
    {
        listeAffiche = self.prevu;
    }
    
    [self.tableView reloadData];
}


@end
