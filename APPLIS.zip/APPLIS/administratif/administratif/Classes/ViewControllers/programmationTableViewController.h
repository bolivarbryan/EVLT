//
//  programmationTableViewController.h
//  administratif
//
//  Created by Emmanuel Levasseur on 18/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Client.h"

@interface programmationTableViewController : UITableViewController {
    NSArray *clients;
    NSArray *clientsCoords;
    NSMutableArray *listeAffiche;
    NSMutableArray *transit;
}

@property (strong, nonatomic) Client *clientAContacter;

@property (strong, nonatomic) NSMutableArray *aProgrammer;
@property (strong, nonatomic) NSMutableArray *progEnCours;
@property (strong, nonatomic) NSMutableArray *prevu;




@end
