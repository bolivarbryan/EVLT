//
//  detailPaiementsTableViewController.m
//  administratif
//
//  Created by Emmanuel Levasseur on 01/06/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "detailPaiementsTableViewController.h"
#import "AppDelegate.h"

#import "Paiement.h"

#import "encaissementsCell.h"

@implementation detailPaiementsTableViewController

- (void)viewDidLoad
{
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    self.client = delegate.clientActif;
    self.paiementsClient = delegate.paiementsClient;
    
    [super viewDidLoad];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [self.paiementsClient count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    Paiement *p = [self.paiementsClient objectAtIndex:indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"%@ de %@ €, le %@ (%@)", p.mode, p.montant, p.date, p.info];
    
    if ([p.info  isEqualToString: @""]) {
        cell.textLabel.text = [NSString stringWithFormat:@"%@ de %@ €, le %@", p.mode, p.montant, p.date];
    }
    
    
    
    return cell;
    
}

@end
