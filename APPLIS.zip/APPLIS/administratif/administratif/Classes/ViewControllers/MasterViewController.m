//
//  MasterViewController.m
//  administratif
//
//  Created by Emmanuel Levasseur on 18/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "MasterViewController.h"
#import "programmationTableViewController.h"
#import "Projet.h"
#import "Client.h"
#import "AppDelegate.h"

@implementation MasterViewController

@synthesize badgeProgrammation;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
 /*   UISegmentedControl *statFilter = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Filter_Personnal", @"Filter_Department", @"Filter_Company", nil]];
    [statFilter sizeToFit];
    self.navigationItem.titleView = statFilter;
  */
    
    [badgeProgrammation setStyle:BadgeLabelStyleAppIcon];
    
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    clients = delegate.clients;
    projets = delegate.projets;
    
//    NSLog(@"LISTE PROJETS RECUS : %@", projets);
    
    [self Update];
    
}

- (void) Update {
    
    self.chantierAProgrammer= [[NSMutableArray alloc] init];
    self.chantierEnCoursProg= [[NSMutableArray alloc] init];
    self.chantierPrevu= [[NSMutableArray alloc] init];
    
    for (Projet *pro in projets) {
        if ([pro.statut isEqualToString:@"A programmer"]) {
            [self.chantierAProgrammer addObject:pro];
        }
        if ([pro.statut isEqualToString:@"Programmation en cours"]) {
            [self.chantierEnCoursProg addObject:pro];
        }
        if ([pro.statut isEqualToString:@"Prevu"]) {
            [self.chantierPrevu addObject:pro];
        }
    }
    
  /*  NSPredicate *programmationPredicate = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        Projet *p = (Projet *)evaluatedObject;
        return p.statut = @"A programmer";
    }];
    self.chantierAProgrammer = [projets filteredArrayUsingPredicate:programmationPredicate];
   
   */
    
 //   NSLog(@"CHANTIER A PROGRAMMER : %@", self.chantierAProgrammer);
    
    badgeProgrammation.text = [NSString stringWithFormat:@"%li", (unsigned long)self.self.chantierAProgrammer.count];
    
}


- (IBAction)programmationBouton:(id)sender {
}

- (IBAction)testPass:(id)sender {
    
    
    /*
    NSString * string = @"bidule";
    NSString * upper = [string uppercaseString];
    
    NSString *alphabet  = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXZY0123456789";
    NSMutableString *s = [NSMutableString stringWithCapacity:20];
    for (NSUInteger i = 0U; i < 5; i++) {
        u_int32_t r = arc4random() % [alphabet length];
        unichar c = [alphabet characterAtIndex:r];
        [s appendFormat:@"%C", c];
    }
    
    NSLog(@"CLIENT : %@ MOT DE PASSE : %@", upper, s);
     
     */
    
}



- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
     if ([[segue identifier] isEqualToString:@"versProgrammation"]) {
     
     programmationTableViewController *dvc = [segue destinationViewController];

     dvc.aProgrammer = self.chantierAProgrammer;
         dvc.progEnCours = self.chantierEnCoursProg;
         dvc.prevu = self.chantierPrevu;

     }

}

@end
