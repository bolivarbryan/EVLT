//
//  paiementViewController.h
//  administratif
//
//  Created by Emmanuel Levasseur on 27/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Client.h"

@interface paiementViewController : UIViewController<UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate>

@property (weak, nonatomic) Client *client;

@property (weak, nonatomic) IBOutlet UITextField *montantTextField;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePaiement;
@property (weak, nonatomic) IBOutlet UIPickerView *modePaiement;
@property (weak, nonatomic) IBOutlet UITextField *infoPaiement;
- (IBAction)paiementBouton:(id)sender;

@end
