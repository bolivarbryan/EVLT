//
//  paiementViewController.m
//  administratif
//
//  Created by Emmanuel Levasseur on 27/05/2015.
//  Copyright (c) 2015 Emmanuel Levasseur. All rights reserved.
//

#import "paiementViewController.h"
#import "encaissementsTableViewController.h"
#import "paiementRequest.h"
#import "Communicator.h"

#import "AppDelegate.h"

@interface paiementViewController ()

{
    NSArray *_pickerData;
}

@end

@implementation paiementViewController

- (void)viewDidLoad
{
    AppDelegate *delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    self.client = delegate.clientActif;
    
    [super viewDidLoad];
    
    self.modePaiement.delegate = self;
    [self.modePaiement resignFirstResponder];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    // Initialize Data
    _pickerData = @[@"Chèque", @"Virement", @"Espèces"];

}

// The number of columns of data
- (long)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// The number of rows of data
- (long)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _pickerData.count;
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return _pickerData[row];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
   // ACTION SI LIGNE CHOISIE
}


- (IBAction)paiementBouton:(id)sender {
    
    NSDate *pickerDate = [self.datePaiement date];
    NSDateFormatter *formatageDate = [[NSDateFormatter alloc] init];
    [formatageDate setDateFormat:@"yyyy-MM-dd"];
    NSString *dateFormatee = [formatageDate stringFromDate:pickerDate];
    
    paiementRequest *request = [[paiementRequest alloc] init];
    request.statut =@"NOUVEAU";
    request.montant = self.montantTextField.text;
    request.date = dateFormatee;
    request.mode = @"Cheque";
    request.info = self.infoPaiement.text;
    request.clientID = self.client.identifier;
    Communicator *comm = [[Communicator alloc] init];
    [comm performRequest:request];
    
    [self.navigationController popViewControllerAnimated:YES]; 
  
}
    
@end
