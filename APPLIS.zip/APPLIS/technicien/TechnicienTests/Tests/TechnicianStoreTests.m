//
//  TechnicianStoreTests.m
//  Technicien
//
//  Created by Benjamin Petit on 26/11/2014.
//  Copyright (c) 2014 En Vert La Terre. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "TechnicianStore.h"

@interface TechnicianStoreTests : XCTestCase

@property (strong, nonatomic) TechnicianStore *store;

@end

@implementation TechnicianStoreTests

- (void)setUp {
    [super setUp];
    
    self.store = [[TechnicianStore alloc] init];
}

- (void)tearDown {
    self.store = nil;
    
    [super tearDown];
}

- (void)testNameSearch {
    Technician *tech1 = [self.store technicianForName:@"Denis"];
    XCTAssertNotNil(tech1, @"Couldn't match names");
    XCTAssertEqualObjects(tech1.name, @"Denis");
    
    Technician *tech2 = [self.store technicianForName:@"denis"];
    XCTAssertNotNil(tech2, @"Couldn't find non capitalized names");
    XCTAssertEqualObjects(tech2.name, @"Denis");
    
    Technician *tech3 = [self.store technicianForName:@"deNis"];
    XCTAssertNotNil(tech3, @"Couldn't find badly capitalized names");
    XCTAssertEqualObjects(tech3.name, @"Denis");
    
    Technician *tech4 = [self.store technicianForName:@"gaëtan"];
    XCTAssertNotNil(tech4, @"Couldn't find accentuated names");
    XCTAssertEqualObjects(tech4.name, @"Gaëtan");
}

@end
