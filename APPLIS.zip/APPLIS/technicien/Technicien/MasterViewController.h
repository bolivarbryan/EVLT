//
//  MasterViewController.h
//  Technicien
//
//  Created by Benjamin Petit on 24/11/2014.
//  Copyright (c) 2014 En Vert La Terre. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

