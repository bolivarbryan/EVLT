//
//  AppDelegate.h
//  Technicien
//
//  Created by Benjamin Petit on 24/11/2014.
//  Copyright (c) 2014 En Vert La Terre. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TechnicianStore.h"
#import "TECProjectManager.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) TechnicianStore *technicianStore;
@property (strong, nonatomic) TECProjectManager *projectManager;

@property (strong, nonatomic) NSArray *projets;
@property (strong, nonatomic) NSArray *clients;
@property (strong, nonatomic) NSArray *coords;

@end

