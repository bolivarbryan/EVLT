//
//  ETIDayCollectionViewCell.m
//  CalendarIOS7
//
//  Created by Jerome Morissard on 3/3/14.
//  Copyright (c) 2014 Jerome Morissard. All rights reserved.
//

#import "CALDayCollectionViewCell.h"
#import "NSDate+Agenda.h"
#import "ProjectforDate.h"

@interface CALDayCollectionViewCell()
@property (strong, nonatomic) UILabel *dayLabel;
@property (strong, nonatomic) UILabel *nbEventsLabel;

//Style
@property (strong, nonatomic) CALayer *separatorLayer;
@property (strong, nonatomic) UIColor *contentViewColor;

//today
@property (strong, nonatomic) CALayer *todayLayer;

//events
@property (strong, nonatomic) CALayer *eventsLayer;
@end

@implementation CALDayCollectionViewCell

- (void)prepareForReuse
{
    [super prepareForReuse];
    [self removeEventsLayer];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _style = CALDayCollectionViewCellDayUIStyleNone;
        
        _dayLabel = [[UILabel alloc] initWithFrame:self.contentView.bounds];
		_dayLabel.textAlignment = NSTextAlignmentCenter;
        [_dayLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Light" size:20.0f]];

        _dayLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_dayLabel];

        _nbEventsLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 29.0f, 44.0f, 15.0f)];
		_nbEventsLabel.textAlignment = NSTextAlignmentRight;
		_nbEventsLabel.font = [UIFont systemFontOfSize:12.0f];
        _nbEventsLabel.backgroundColor = [UIColor clearColor];
		[self addSubview:_nbEventsLabel];
        
    }
    return self;
}

#pragma mark - Overided setter 

- (void)setStyle:(CALDayCollectionViewCellDayUIStyle)style
{
    if (_style == style) {
        return;
    }
    
    if (style == CALDayCollectionViewCellDayUIStyleIOS7) {
        _separatorLayer = [[CALayer alloc] init];
        [_separatorLayer setBackgroundColor:[UIColor lightGrayColor].CGColor];
        [_separatorLayer setFrame:CGRectMake(-2.0f, 0.0f, 46.0f, 1.0f)];
        [self.layer addSublayer:_separatorLayer];
        self.contentViewColor = [UIColor clearColor];
        self.clipsToBounds = NO;
    }
    else {
        [_separatorLayer removeFromSuperlayer];
        _separatorLayer = nil;
        self.clipsToBounds = YES;
        self.contentViewColor = [[UIColor blueColor] colorWithAlphaComponent:0.05f];
    }
    
    _style = style;
}


#pragma mark - Updates

- (void)updateCellWithDate:(NSDate *)date
{
    self.dayLabel.text = [NSString stringWithFormat:@"%ld", (long)[date dayComponents]];
}

- (void)updateCellWithDate:(NSDate *)date andEvents:(NSInteger)nbEvents
{
    [self updateCellWithDate:date];
    
    //   NSLog(@"NOMBRE EVENEMENTS : %li A DATE %@", (long)nbEvents, date);
    
    if (nbEvents > 0) {
     //   self.nbEventsLabel.text = [NSString stringWithFormat:@"%ld", (long)nbEvents];
    } else {
        self.nbEventsLabel.text = @"";
    }
    
    [self removeEventsLayer];
    if (nbEvents > 0) {
        
      //  NSLog(@"DATE AVEC AJOUT : %@", date);
        
        self.nombreEvenements = nbEvents;
        [self addEventsLayer];
    }
}

- (void)setType:(CALDayCollectionViewCellDayType)type
{
    _type = type;

    self.backgroundColor = [UIColor clearColor];
    [self removeTodayLayer];
    [self setUserInteractionEnabled:YES];
    self.dayLabel.textColor = [UIColor blackColor];

    switch (type) {
        case CALDayCollectionViewCellDayTypeEmpty:
            self.dayLabel.text = @"";
            [self.contentView setBackgroundColor:[UIColor clearColor]];
            [self.contentView.layer setCornerRadius:0.0f];
            [self.separatorLayer setBackgroundColor:[UIColor clearColor].CGColor];
            [self setUserInteractionEnabled:NO];
            break;
            
        case CALDayCollectionViewCellDayTypeToday:
            self.dayLabel.text = @"";
            self.dayLabel.textColor = [UIColor whiteColor];
            self.todayLayer = [[CALayer alloc] init];
            [self.todayLayer setFrame:CGRectMake(6.0f, 6.0f, 32.0f, 32.0f)];
            [self.todayLayer setBackgroundColor:[UIColor redColor].CGColor];
            [self.todayLayer setCornerRadius:16.0f];
         //   [self.contentView.layer addSublayer:self.todayLayer];
            [self.contentView setBackgroundColor:self.contentViewColor];
            [self.separatorLayer setBackgroundColor:[UIColor lightGrayColor].CGColor];
            break;
     
        case CALDayCollectionViewCellDayTypePast:
         /*   self.dayLabel.text = @"";
            [self.contentView setBackgroundColor:self.contentViewColor];
            [self.contentView.layer setCornerRadius:0.0f];
            [self.separatorLayer setBackgroundColor:[UIColor greenColor].CGColor];
            break; */
        case CALDayCollectionViewCellDayTypeFutur:
            self.dayLabel.text = @"";
            [self.contentView setBackgroundColor:self.contentViewColor];
            [self.contentView.layer setCornerRadius:0.0f];
            [self.separatorLayer setBackgroundColor:[UIColor lightGrayColor].CGColor];
            break;
            
        default:
            break;
    }
}

- (void)removeTodayLayer
{
    if ( nil != self.todayLayer) {
        [self.todayLayer removeFromSuperlayer];
        self.todayLayer = nil;
    }
}

#pragma mark - eventLayer

- (void)addEventsLayer
{
    // SYMBOLE SI EVENEMENT
    
    NSString *nombre = [NSString stringWithFormat:@"%li", self.nombreEvenements];
    
    int largeurLayer = 70;
    int hauteurLayer = 40;
    
    CALayer *sublayer = [CALayer layer];
    sublayer.backgroundColor = [UIColor blueColor].CGColor;
    sublayer.shadowOffset = CGSizeMake(0, 3);
    sublayer.shadowRadius = 5.0;
    sublayer.shadowColor = [UIColor blackColor].CGColor;
    sublayer.shadowOpacity = 0.8;
    sublayer.frame = CGRectMake(CGRectGetMidX(self.bounds)- largeurLayer/2, CGRectGetMidY(self.bounds) +hauteurLayer/4, largeurLayer, hauteurLayer);
    sublayer.borderColor = [UIColor blackColor].CGColor;
    sublayer.borderWidth = 2.0;
    sublayer.cornerRadius = 10.0;
    [self.layer addSublayer:sublayer];
    
    CALayer *imageLayer = [CALayer layer];
    imageLayer.frame = sublayer.bounds;
    imageLayer.cornerRadius = 10.0;
    imageLayer.contents = (id) [UIImage imageNamed:@"cle.jpg"].CGImage;
    imageLayer.masksToBounds = YES;
    [sublayer addSublayer:imageLayer];
    
    CATextLayer *label = [[CATextLayer alloc] init];
    [label setFont:@"Helvetica-Bold"];
    [label setFontSize:20];
    [label setFrame:sublayer.bounds];
    [label setString:nombre];
    [label setAlignmentMode:kCAAlignmentCenter];
    [label setForegroundColor:[[UIColor redColor] CGColor]];
    [sublayer addSublayer:label];
    
}

- (void)removeEventsLayer
{
    [self.eventsLayer removeFromSuperlayer];
    self.eventsLayer = nil;
}

@end
