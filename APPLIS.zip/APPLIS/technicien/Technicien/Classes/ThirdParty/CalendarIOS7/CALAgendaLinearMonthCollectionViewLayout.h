//
//  CALAgendaLinearMonthCollectionViewLayout.h
//  CalendarIOS7
//
//  Created by jerome morissard on 21/06/14.
//  Copyright (c) 2014 Jerome Morissard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CALAgendaLinearMonthCollectionViewLayout : UICollectionViewFlowLayout

@end
