//
//  CALCollectionViewFlowLayoutWithStickyHeader.h
//  CalendarIOS7
//
//  Created by Jerome Morissard on 3/22/14.
//  Copyright (c) 2014 Jerome Morissard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CALCollectionViewFlowLayoutWithStickyHeader : UICollectionViewFlowLayout

@end
