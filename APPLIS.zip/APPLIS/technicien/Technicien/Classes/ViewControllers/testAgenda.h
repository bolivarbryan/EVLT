//
//  testAgenda.h
//  Technicien
//
//  Created by Emmanuel Levasseur on 16/05/2015.
//  Copyright (c) 2015 En Vert La Terre. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GTMOAuth2ViewControllerTouch.h"
#import "GTLCalendar.h"

@interface testAgenda : UIViewController

@property (nonatomic, strong) GTLServiceCalendar *calendarService;
@property (nonatomic, strong) UILabel *output;

@property (strong, nonatomic) NSMutableArray *evenements;



- (IBAction)testBouton:(id)sender;

@end
