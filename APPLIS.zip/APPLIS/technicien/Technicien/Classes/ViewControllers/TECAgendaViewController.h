//
//  TECAgendaViewController.h
//  Technicien
//
//  Created by Benjamin Petit on 24/11/2014.
//  Copyright (c) 2014 En Vert La Terre. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GTMOAuth2ViewControllerTouch.h"

#import "CALAgendaViewController.h"

@interface TECAgendaViewController : CALAgendaViewController

@property (nonatomic, strong) GTLServiceCalendar *calendarService;
@property (nonatomic, strong) UILabel *output;

@property (strong, nonatomic) NSMutableArray *evenements;

@end


