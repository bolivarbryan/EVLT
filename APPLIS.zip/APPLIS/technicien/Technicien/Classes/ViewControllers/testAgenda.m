//
//  testAgenda.m
//  Technicien
//
//  Created by Emmanuel Levasseur on 16/05/2015.
//  Copyright (c) 2015 En Vert La Terre. All rights reserved.
//

#import "testAgenda.h"
#import "AppDelegate.h"
#import "TECAgendaViewController.h"

static NSString *const kKeychainItemName = @"Google Calendar Quickstart";
static NSString *const kClientID = @"340967554983-7fhuo5ds1kgf0heo2jkv6v95k8qe47fu.apps.googleusercontent.com";
static NSString *const kClientSecret = @"JMd38E8CbSza8YPn_jhJGgv9";


@implementation testAgenda

@synthesize calendarService = _calendarService;
@synthesize output = _output;

// When the view loads, create necessary subviews, and initialize the Calendar service.
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Create a UILabel to display output.
    self.output = [[UILabel alloc] init];
    self.output.frame = self.view.bounds;
    self.output.numberOfLines = 0;
    self.output.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.output.text = @"Getting events...";
    [self.view addSubview:self.output];
    
    // Initialize the Calendar service & load existing credentials from the keychain if available.
    self.calendarService = [[GTLServiceCalendar alloc] init];
    self.calendarService.authorizer =
    [GTMOAuth2ViewControllerTouch authForGoogleFromKeychainForName:kKeychainItemName
                                                          clientID:kClientID
                                                      clientSecret:kClientSecret];
}

// When the view appears, ensure that the Calendar service is authorized, and perform API calls.
- (void)viewDidAppear:(BOOL)animated {
    if (!self.calendarService.authorizer.canAuthorize) {
        // Not yet authorized, request authorization by pushing the login UI onto the UI stack.
        [self presentViewController:[self createAuthController] animated:YES completion:nil];
        
    } else {
        [self fetchEvents];
    }
}

// Construct a query and get a list of upcoming events from the user calendar. Display the
// start dates and event summaries in the UILabel.
- (void)fetchEvents {
    GTLQueryCalendar *query = [GTLQueryCalendar queryForEventsListWithCalendarId:@"primary"];
    query.maxResults = 10;
    query.timeMin = [GTLDateTime dateTimeWithDate:[NSDate date]
                                         timeZone:[NSTimeZone localTimeZone]];;
    query.singleEvents = @YES;
    query.orderBy = kGTLCalendarOrderByStartTime;
    
    [self.calendarService executeQuery:query
                     completionHandler:^(GTLServiceTicket *ticket, GTLCalendarEvents *events, NSError *error) {
                         if (error == nil) {
                             NSMutableString *eventString = [[NSMutableString alloc] init];
                             if (events.items.count == 0) {
                                 [eventString appendString:@"No upcoming events found."];
                             } else {
                                 
                                 NSMutableArray*listeCharge = [[NSMutableArray alloc] init];
                                 

                                 [eventString appendString:@"Upcoming 10 events:\n"];
                                 for (GTLCalendarEvent *event in events) {
                                   //  NSLog(@"DETAIL EVENT : %@", event);
                                     
                                     [listeCharge addObject:event];
                                     
                                     self.evenements = listeCharge;
                                     
                                    // NSLog(@"AJOUT");
                                    // NSLog(@"TABLEAU EVENEMENTS : %@", self.evenements);
                                     GTLDateTime *start = event.start.dateTime ?: event.start.date;
                                     NSString *startString =
                                     [NSDateFormatter localizedStringFromDate:[start date]
                                                                    dateStyle:NSDateFormatterShortStyle
                                                                    timeStyle:NSDateFormatterShortStyle];
                                     
                                     GTLDateTime *end = event.end.dateTime ?: event.end.date;
                                     NSString *endString =
                                     [NSDateFormatter localizedStringFromDate:[end date]
                                                                    dateStyle:NSDateFormatterShortStyle
                                                                    timeStyle:NSDateFormatterShortStyle];
                                     
                                     [eventString appendFormat:@"%@ à %@ - %@\n", startString, endString, event.summary];
                                 }
                                 self.output.text = eventString;
                             }
                         } else {
                             [self showAlert:@"Error" message:@"Unable to get calendar events."];
                         }
                         
                     }];

}

// Creates the auth controller for authorizing access to Google Calendar.
- (GTMOAuth2ViewControllerTouch *)createAuthController {
    GTMOAuth2ViewControllerTouch *authController;
    authController = [[GTMOAuth2ViewControllerTouch alloc] initWithScope:kGTLAuthScopeCalendarReadonly
                                                                clientID:kClientID
                                                            clientSecret:kClientSecret
                                                        keychainItemName:kKeychainItemName
                                                                delegate:self
                                                        finishedSelector:@selector(viewController:finishedWithAuth:error:)];
    return authController;
}

// Handle completion of the authorization process, and update the Calendar service
// with the new credentials.
- (void)viewController:(GTMOAuth2ViewControllerTouch *)viewController
      finishedWithAuth:(GTMOAuth2Authentication *)authResult
                 error:(NSError *)error {
    if (error != nil) {
        [self showAlert:@"Authentication Error" message:error.localizedDescription];
        self.calendarService.authorizer = nil;
    }
    else {
        self.calendarService.authorizer = authResult;
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

// Helper for showing an alert
- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertView *alert;
    alert = [[UIAlertView alloc] initWithTitle:title
                                       message:message
                                      delegate:nil
                             cancelButtonTitle:@"OK"
                             otherButtonTitles:nil];
    [alert show];
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    
    if ([[segue identifier] isEqualToString:@"testSegue"]) {
        
        TECAgendaViewController *dvc = [segue destinationViewController];
        
        dvc.events = self.evenements;


    }
    

}
 

- (IBAction)testBouton:(id)sender {
    
 //   NSLog(@"EVENEMENTS : %@", self.evenements);
    
}
@end
