//
//  MapViewController.h
//  Technicien
//
//  Created by Benjamin Petit on 24/11/2014.
//  Copyright (c) 2014 En Vert La Terre. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Projet.h"

@interface MapViewController : UIViewController {
    NSMutableArray *listeAffiche;
    NSMutableArray *transitClient;
    NSArray *clients;
    NSArray *projets;
}

@property (strong, nonatomic) Projet *projet;

@property (strong, nonatomic) CLGeocoder *geocoder;

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property(weak, nonatomic) CLLocation *locTest;

@property(weak, nonatomic) NSString *addressText;

@end
